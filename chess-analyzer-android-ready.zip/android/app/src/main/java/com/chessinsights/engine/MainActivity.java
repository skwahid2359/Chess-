package com.chessinsights.engine;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
