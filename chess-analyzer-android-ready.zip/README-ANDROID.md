# Build the Android APK

This project is configured as a Capacitor Android app that bundles the web app locally. No hosted website URL is required. The bundled Stockfish worker and WASM are copied into Android assets.

## Requirements

- Node.js 20 or newer and pnpm
- Android Studio with Android SDK Platform 36 installed; Gradle downloads any required build tools on the first build
- JDK 21 (the checked Android Gradle plugin uses the project's Java 21 toolchain)

## Build a debug APK from a terminal

From the project root, install dependencies and build/sync the local web assets:

```bash
pnpm install
pnpm build:android
```

Then compile the debug APK.

**Windows PowerShell:**

```powershell
cd android
.\gradlew.bat assembleDebug
```

**macOS or Linux:**

```bash
cd android
./gradlew assembleDebug
```

The APK is written to:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

You can install it on a connected Android device with `adb install -r android/app/build/outputs/apk/debug/app-debug.apk`, or copy that APK to the phone and open it. Enable “Install unknown apps” for the file manager if Android asks.

## Build using Android Studio

Run `pnpm build:android` first. Then open the `android/` folder in Android Studio, allow Gradle sync and install SDK Platform 36 / Build Tools 36.0.0 if prompted. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The debug APK uses a debug signing key and is for testing; publishing on Play Store requires a separately generated release signing key and release build.

## After changing web code

Run `pnpm build:android` again before rebuilding the Android APK. This regenerates the SPA shell and syncs the latest JS, CSS, images and Stockfish files into the native project.
