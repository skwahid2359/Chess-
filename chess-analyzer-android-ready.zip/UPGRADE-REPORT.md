# Chess Analyzer Upgrade — Implementation Report

## Current checkpoint

This is a source-level upgrade of the supplied `chess-game-analyzer_v6` project. The existing Analyzer remains available; the new Bot Arena is an additional workspace. This checkpoint implements a substantial first feature slice, not every item in the original full acceptance list. See `TODO.md` for items that are intentionally still open.

## Delivered in this source checkpoint

- Added a primary Analyzer / Bot Arena switch and responsive Bot Arena overview with entry points for Bot Play, Brilliant Hunter, Discovery Lab, DNA Explorer, Human vs Hunter, Training, Benchmark and Game History.
- Refined the Bot Arena overview header to match the existing Analyzer's compact workspace styling. Both workspaces use the same dark background, amber primary, IBM Plex Sans / JetBrains Mono typography, shared panel/border tokens and chessboard components; a desktop browser preview was checked side by side. Mobile visual QA remains unverified.
- Added bot profiles from Beginner to Ultimate using real Stockfish UCI strength/depth controls. The app states that UCI Elo is an uncalibrated engine-control target, not an independently measured player rating. Experimental playing styles select among engine lines within a capped score tolerance.
- Added an optional Ultimate-only **Brilliant Search** style: on each bot turn it requests Stockfish MultiPV lines for the full current legal root-move set with an 8-second per-turn cap. It only biases toward a material/tactical line within 2.5 mover win-percentage points of the best when all legal moves are covered at the same reported depth; otherwise it falls back to the best returned line. Coverage is displayed. This is not exhaustive game-tree search and does not label the chosen move Hunter-verified Brilliant.
- Added legal bot games using `chess.js` and the existing board: White/Black/random, clocks and increment, board flip, move history, undo, resign/restart, live engine status/evaluation, PGN export, and local game history with individual deletion.
- Reused the existing Stockfish 19 Lite single-thread Web Worker/WASM assets and extended the existing UCI wrapper for strength/time settings and safer cancellation/destruction behavior.
- Configured TanStack Start SPA-shell output as `.output/public/index.html`, added Capacitor Android 8, and generated the native `android/` Gradle project. `capacitor.config.ts` bundles `.output/public` locally—no remote web URL is configured—and includes the local Stockfish JS/WASM assets.
- Added `pnpm build:android` to rebuild the SPA and sync it to Android, plus `README-ANDROID.md` with Windows/macOS/Linux debug-APK steps.
- Added PGN upload/paste/recent-bot-game scanning and a FEN-based single-position Discovery Lab. Scans are bounded by Fast/Balanced/Deep depth and position/candidate limits, provide progress and pause/resume/cancel, compare engine MultiPV candidates, inspect the strongest searched reply, and show before/after boards, evaluations, variation and confidence.
- Hunter confirmation is conservative: only an engine-classified brilliant move meeting the current depth-20/multi-line gate can be stored as verified. Shallow results remain provisional. Routine moves are filtered out; “Refuted” is reserved for a material sacrifice that the searched line rejects. Engine searches are finite-horizon evidence, not mathematical proofs.
- Added IndexedDB-backed verified discovery and bot-game storage with a bounded localStorage fallback. DNA Explorer exposes verified-only records, source PGN export, derived tags, normalized piece-structure similarity, individual deletion and JSON export. Similarity is explicitly described as a search aid, not proof of the same tactic.
- Added Human-vs-Hunter/Training screens that use verified discoveries only, with legal attempts, hints/reveal and local practice statistics.
- Added a benchmark runner for a user-supplied, source-attributed JSON position set. Precision/recall/error/coverage metrics are calculated only from completed actual runs; there is no fabricated default benchmark score or hardcoded game answer.

## Verification performed

- `pnpm test -- --reporter=dot`: **16 tests passed** across Analyzer classification/routing, bot line-selection guardrails, all-legal Brilliant Search coverage and fallback, Hunter depth verification, verified-only DNA filtering and UCI worker cancellation.
- `pnpm exec tsc --noEmit`: **passed**.
- `pnpm lint`: **0 errors**; six pre-existing `react-refresh/only-export-components` warnings remain in shared UI component files.
- `pnpm build`: production web build completed successfully after the latest source changes.
- The supplied source tree contains the bundled `public/stockfish/stockfish-19-lite-single.js` and matching `.wasm` files.
- `./gradlew --no-daemon assembleDebug`: **BUILD SUCCESSFUL** using JDK 21, Android API 36 and Build Tools 36.0.0. Generated `android/app/build/outputs/apk/debug/app-debug.apk` (debug-signed, 5.6 MB). The APK archive was checked for the app package metadata and bundled Stockfish assets; no physical-device/emulator installation test has been run.

### Test evidence by feature

| Area | Current evidence | Not covered by automated tests yet |
|---|---|---|
| Existing Analyzer | Four classification tests and one routing test pass; production build succeeds. | Full PGN-import-to-report browser flow and Android WebView. |
| Bot Arena | Tests cover style score guardrails plus Brilliant Search coverage, score tolerance, equal-depth comparison, and incomplete-search fallback. | Real Stockfish/WASM full branching-factor latency and output coverage; end-to-end board legality, clocks, promotion, all difficulty settings and game persistence UI. |
| Brilliant Hunter | Unit tests require the current depth/multi-line gate for confirmation and ensure shallower findings remain provisional. | Real Stockfish benchmark positions, false-positive/negative corpus and large-PGN performance. |
| DNA Explorer | Unit test confirms unverified findings are excluded from verified-pattern similarity. | Browser CRUD/export flow and motif-by-motif relevance evaluation. |
| Human vs Hunter / Training | Screens use verified-only discovery records. | Dedicated puzzle-flow, alternate-solution and performance-stat tests. |
| Discovery Benchmark | Runner calculates metrics from completed imported datasets in application code. | Dedicated import/metric/history UI tests and a curated benchmark dataset. |
| Engine lifecycle / Android packaging | Two mocked-worker tests cover cancellation before ready and promise settlement on destruction; Gradle debug APK compiles and contains local web/Stockfish assets. | Device-specific WebView worker/WASM behavior, Android UI/device install test, resource limits and long-running stress tests. |

## Not yet delivered / not claimed

- The Android project and **debug APK** are now generated. This is a debug-signed test build, not a Play Store release. Test it on a real Android device before distribution; release signing and Play Store packaging still need a production keystore and release build.
- Bot-game end screens do not yet provide the full existing-Analyzer report (classification, accuracy, opening/turning-point summary), and saved games are not yet resumable as bot games or clearable as a batch.
- Hunter currently investigates actual moves in the imported game and engine-ranked candidate moves for a FEN. It does not yet exhaustively enumerate and prove every motif/variation, model all sacrifice types/king-safety signals, or perform a complete tactical/strategic motif taxonomy. The difficulty label is a heuristic signal, not a probability.
- Discovery Lab currently accepts FEN text rather than a full board editor/PGN variation setup. Android WebView and dense/mobile visual behavior have not been device-tested.
- Training has random verified puzzles and basic local stats, but not the complete difficulty ladder, Daily Challenge, motif/sacrifice filters, exhaustive equivalent-solution checking or full incorrect-answer review.
- The benchmark runner has no bundled curated corpus yet (including Kasparov–Topalov 1999); benchmark results require the user to provide attributed reference positions and annotations.
- The user's full original request also calls for deeper candidate verification, historical versioned benchmark comparison, larger-game and false-positive testing, full Analyzer handoff, memory/performance profiling, and broader mobile validation. These remain tracked in `TODO.md`.
- Brilliant Search is bounded by an 8-second timer, so some high-branching positions may not return every legal move at comparable depth. In that case it reports incomplete/non-comparable coverage and falls back; it does not falsely claim it inspected or verified all candidates. No real-device Stockfish latency benchmark has been run yet.

## Run locally

From the project root:

```bash
pnpm install
pnpm dev
```

Build and validate with:

```bash
pnpm test -- --reporter=dot
pnpm exec tsc --noEmit
pnpm lint
pnpm build
```

## Main changed files

- `src/routes/index.tsx`
- `src/components/arena/BotArena.tsx`
- `src/components/arena/BotGame.tsx`
- `src/components/arena/HunterWorkspace.tsx`
- `src/components/arena/DNAExplorer.tsx`
- `src/components/arena/PuzzleWorkspace.tsx`
- `src/components/arena/BenchmarkDashboard.tsx`
- `src/lib/arena/{bots,dna,hunter,storage,types}.ts`
- `src/lib/arena/brilliant-search.ts`
- `src/lib/chess/{engine,classify,pgn,types}.ts`
- `src/test/{arena,engine-lifecycle}.test.ts`
- `capacitor.config.ts`, `android/`, `README-ANDROID.md`, `vite.config.ts`
- `package.json`, `pnpm-lock.yaml`, `eslint.config.js`, `TODO.md`
