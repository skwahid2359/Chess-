# Chess Insights Engine Upgrade — Implementation Plan

## Current project facts

The supplied source is a TanStack Start/React/TypeScript application. Its single `/` route contains the existing Analyzer. `chess.js` handles legal chess rules and PGN replay; `src/lib/chess/engine.ts` wraps the bundled Stockfish 19 Lite single-thread WASM worker; `use-analysis.ts` owns separate live and review workers; `classify.ts` implements the existing engine-based analyzer labels. Existing board/evaluation bar/components/styles are reusable and must remain intact. The source ZIP has no Android/Capacitor project directory or APK build scripts; the APK from the earlier ZIP is a separate compiled artifact.

## Approach

Preserve the Analyzer as a separate selectable workspace. Add Bot Arena as an integrated workspace that reuses `Board`, `EvalBar`, `chess.js`, PGN parsing, the bundled Stockfish worker and existing design tokens. Extend the UCI wrapper compatibly (old calls retain existing behavior) for engine strength settings, MultiPV and bounded search. A bot-game controller will use legal `chess.js` state transitions, enforce turn order and serialize/cancel engine requests. Distinct personality modes must influence candidate choice and be clearly marked experimental if the behavior is heuristic rather than calibrated.

Build Brilliant Hunter as an asynchronous, cancellable, bounded scan over reconstructed PGN positions. It will compare played/candidate moves with real Stockfish analyses, record strongest opponent responses and distinguish objective score/soundness, tactical complexity, human-discovery difficulty and confidence. Only engine-verified records may be treated as confirmed or enter verified DNA/training; insufficient depth remains provisional. No famous move, benchmark metric, or engine score will be hardcoded as a runtime finding.

Use IndexedDB for larger games/scan records, versioned typed records and explicit export/delete operations. Keep candidate/unverified results separate from verified discoveries. Add DNA pattern comparison using normalized piece relationships/motifs and variations rather than exact-FEN equality alone. Human-vs-Hunter and puzzle training must consume only verified records. Benchmark measurements must be computed from actual runs against attributed references; missing coverage or unverified positions must remain visible rather than hidden.

Keep resource use bounded: one engine owner per active workspace where feasible, queue/cancel jobs, depth/time/position caps, mobile-safe defaults, progress reporting, pause/resume, cancellation and cleanup. Existing Analyzer remains untouched behaviorally and gets regression coverage.

## Project structure

- `src/routes/index.tsx`: preserve `/` and provide the Analyzer/Bot Arena workspace switch.
- `src/components/chess/`: existing reusable board and evaluation components; extend only with backward-compatible options when required.
- `src/components/arena/`: Arena home, bot game, Hunter scan/report, Discovery Lab, DNA, human training and benchmark UI, split into focused modules.
- `src/lib/chess/engine.ts`: shared-compatible Stockfish UCI lifecycle/options/search/cancellation/cache.
- `src/lib/arena/`: typed bot profiles, Hunter scoring/verification, persistence, DNA normalization/search, puzzle selection and benchmark metrics.
- `src/hooks/`: focused state hooks for game and cancellable scans.
- `src/test/`: regression and feature tests using deterministic engine fixtures; fake fixtures are test-only and never presented as runtime engine results.
- `public/stockfish/`, `public/pieces/`: preserve the current worker/WASM and piece assets/paths.

## Design direction

Reuse the existing premium dark chess-analysis language rather than redesigning unrelated sections: IBM Plex Sans plus JetBrains Mono, charcoal panels, amber primary accent, cyan brilliant markers, existing board themes and clear evaluation/classification colors. The Arena should feel like a deliberate extension of the Analyzer with compact responsive navigation, a board-first play layout and restrained engine/status panels. Interactions must expose real engine state and analysis progress; avoid mock results or decorative controls.

## Delivery scope discipline

This is a multi-phase product brief. Implement and verify deliverable feature slices without calling the complete upgrade finished prematurely. Mark unimplemented requirements and Android-specific verification honestly. A web build is not an Android APK; only claim an APK after an actual native build produces and verifies one.
