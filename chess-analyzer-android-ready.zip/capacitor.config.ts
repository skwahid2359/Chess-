import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.chessinsights.engine",
  appName: "Chess Insights Engine",
  webDir: ".output/public",
};

export default config;
