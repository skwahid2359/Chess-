import { afterEach, describe, expect, it, vi } from "vitest";
import { UciEngine } from "@/lib/chess/engine";

class MockWorker {
  static instances: MockWorker[] = [];
  onmessage: ((event: MessageEvent) => void) | null = null;
  onerror: (() => void) | null = null;
  messages: string[] = [];
  terminated = false;
  constructor(_url: string) {
    MockWorker.instances.push(this);
  }
  postMessage(message: string) {
    this.messages.push(message);
    if (message === "uci")
      queueMicrotask(() => this.onmessage?.({ data: "uciok" } as MessageEvent));
    if (message === "isready")
      queueMicrotask(() => this.onmessage?.({ data: "readyok" } as MessageEvent));
  }
  terminate() {
    this.terminated = true;
  }
}

afterEach(() => {
  vi.clearAllTimers();
  vi.unstubAllGlobals();
  vi.useRealTimers();
  MockWorker.instances = [];
});

describe("UCI engine lifecycle", () => {
  it("settles a queued search cancelled before readiness", async () => {
    vi.useFakeTimers();
    vi.stubGlobal("Worker", MockWorker as unknown as typeof Worker);
    const engine = new UciEngine();
    const search = engine.analyze("startpos", 8, 1);
    engine.cancel();
    await expect(search).resolves.toBeNull();
    engine.destroy();
  });

  it("settles the active search promise when its worker is destroyed", async () => {
    vi.useFakeTimers();
    vi.stubGlobal("Worker", MockWorker as unknown as typeof Worker);
    const engine = new UciEngine();
    await Promise.resolve();
    await Promise.resolve();
    expect(engine.status).toBe("ready");
    const search = engine.analyze("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", 8, 1);
    const worker = MockWorker.instances[0];
    expect(worker.messages.some((message) => message.startsWith("go depth"))).toBe(true);
    engine.destroy();
    await expect(search).resolves.toBeNull();
    expect(worker.terminated).toBe(true);
  });
});
