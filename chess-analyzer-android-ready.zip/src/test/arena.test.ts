import { Chess } from "chess.js";
import { describe, expect, it } from "vitest";
import { selectBotLine } from "@/lib/arena/bots";
import { selectBrilliantSearchLine } from "@/lib/arena/brilliant-search";
import { scoreHunterMove } from "@/lib/arena/hunter";
import { findSimilarPatterns } from "@/lib/arena/dna";
import { toNode } from "@/lib/chess/pgn";
import type { EngineResult, PvLine } from "@/lib/chess/types";
import type { HunterFinding } from "@/lib/arena/types";

const line = (multipv: number, cp: number, pv: string[]): PvLine => ({
  multipv,
  depth: 20,
  score: { cp },
  pv,
});

describe("Bot line selection guardrails", () => {
  it("chooses an engine-legal near-equal tactical line for an experimental aggressive style", () => {
    const fen = "r3k3/8/8/8/8/8/8/R3K3 w - - 0 1";
    const candidates = [line(1, 0, ["e1d1"]), line(2, -10, ["a1a8"])];
    expect(selectBotLine(fen, "w", candidates, "balanced")?.pv[0]).toBe("e1d1");
    expect(selectBotLine(fen, "w", candidates, "aggressive")?.pv[0]).toBe("a1a8");
  });

  it("does not let a style heuristic choose a line outside the 2.5 win-point tolerance", () => {
    const fen = "r3k3/8/8/8/8/8/8/R3K3 w - - 0 1";
    const candidates = [line(1, 0, ["e1d1"]), line(2, -300, ["a1a8"])];
    expect(selectBotLine(fen, "w", candidates, "aggressive")?.pv[0]).toBe("e1d1");
  });
});

describe("Brilliant Search coverage and safety", () => {
  const fen = "4k3/8/8/6b1/8/8/8/R3K3 w - - 0 1";
  const allLegalLines = (sacrificeScore = -10) => {
    const moves = new Chess(fen).moves({ verbose: true });
    return moves.map((move, index) => {
      const uci = move.from + move.to + (move.promotion ?? "");
      const cp = uci === "e1d1" ? 0 : uci === "a1c1" ? sacrificeScore : -30;
      return line(index + 1, cp, [uci]);
    });
  };

  it("searches every legal move and may choose a sound near-best sacrifice instead of the quiet top line", () => {
    const result = selectBrilliantSearchLine(fen, "w", allLegalLines());
    expect(result.completeCoverage).toBe(true);
    expect(result.coveredMoveCount).toBe(result.legalMoveCount);
    expect(result.line?.pv[0]).toBe("a1c1");
    expect(result.choseTacticalAlternative).toBe(true);
  });

  it("keeps the engine's best move when a tactical candidate exceeds the score guardrail", () => {
    const result = selectBrilliantSearchLine(fen, "w", allLegalLines(-400));
    expect(result.completeCoverage).toBe(true);
    expect(result.line?.pv[0]).toBe("e1d1");
    expect(result.choseTacticalAlternative).toBe(false);
  });

  it("avoids comparing evaluations from mismatched search depths", () => {
    const lines = allLegalLines().map((candidate) =>
      candidate.pv[0] === "a1c1" ? { ...candidate, depth: candidate.depth - 1 } : candidate,
    );
    const result = selectBrilliantSearchLine(fen, "w", lines);
    expect(result.completeCoverage).toBe(true);
    expect(result.scoreComparable).toBe(false);
    expect(result.line?.pv[0]).toBe("e1d1");
    expect(result.choseTacticalAlternative).toBe(false);
  });

  it("does not pretend legal-move coverage is complete when Stockfish omitted a candidate", () => {
    const lines = allLegalLines().filter((candidate) => candidate.pv[0] !== "a1c1");
    const result = selectBrilliantSearchLine(fen, "w", lines);
    expect(result.completeCoverage).toBe(false);
    expect(result.coveredMoveCount).toBe(result.legalMoveCount - 1);
    expect(result.line?.pv[0]).toBe("e1d1");
    expect(result.choseTacticalAlternative).toBe(false);
  });
});

function sacrificeFixture(depth: number): {
  finding: HunterFinding;
  before: EngineResult;
  after: EngineResult;
} {
  const chess = new Chess("4k3/8/8/6b1/8/8/8/R3K3 w - - 0 1");
  const move = toNode(chess.move("Rc1"), 0);
  const before: EngineResult = {
    fen: move.fenBefore,
    depth,
    lines: [
      { ...line(1, 0, ["a1c1"]), depth },
      { ...line(2, -500, ["a1a2"]), depth },
      { ...line(3, -600, ["e1d1"]), depth },
    ],
  };
  const after: EngineResult = {
    fen: move.fenAfter,
    depth,
    lines: [
      { ...line(1, 0, ["g5c1"]), depth },
      { ...line(2, -50, ["e8d7"]), depth },
    ],
  };
  const finding = scoreHunterMove(move, before, after);
  if (!finding) throw new Error("Synthetic sacrifice should remain an investigated candidate.");
  return { finding, before, after };
}

describe("Hunter verification gate", () => {
  it("keeps a shallower engine-brilliant sacrifice provisional", () => {
    const { finding } = sacrificeFixture(14);
    expect(finding.classification).toBe("Needs Deeper Analysis");
    expect(finding.verified).toBe(false);
    expect(finding.confidence).toBe("Low — provisional");
  });

  it("requires high-depth multi-line evidence before confirming a brilliant sacrifice", () => {
    const { finding } = sacrificeFixture(20);
    expect(finding.classification).toBe("Confirmed Brilliant");
    expect(finding.verified).toBe(true);
    expect(finding.confidence).toBe("High");
    expect(finding.actualMoveUci).toBe("a1c1");
  });
});

const stored = (overrides: Partial<HunterFinding> = {}): HunterFinding => ({
  id: "verified-1",
  discoveredAt: "2026-01-01T00:00:00.000Z",
  ply: 0,
  moveNumber: 1,
  actualMove: "Rc1",
  color: "w",
  fenBefore: "4k3/8/8/6b1/8/8/8/R3K3 w - - 0 1",
  fenAfter: "4k3/8/8/6b1/8/8/8/2R1K3 b - - 1 1",
  classification: "Confirmed Brilliant",
  confidence: "High",
  verified: true,
  engineDepth: 20,
  candidateCount: 3,
  before: { cp: 0 },
  after: { cp: 0 },
  winChanceLoss: 0,
  actualMoveUci: "a1c1",
  bestMoveUci: "a1c1",
  mainVariation: ["Rc1"],
  materialSacrifice: "rook",
  tacticalComplexity: "High",
  discoveryDifficulty: "High",
  explanation: "Synthetic test fixture.",
  ...overrides,
});

describe("verified DNA similarity", () => {
  it("excludes unverified candidates from structural pattern search", () => {
    const target = stored();
    const candidate = stored({
      id: "candidate",
      verified: false,
      classification: "Strong Candidate",
    });
    expect(findSimilarPatterns(target, [target, candidate])).toEqual([]);
  });
});
