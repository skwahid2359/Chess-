import { Chess, type Square } from "chess.js";
import { classifyMove, detectMaterialSacrifice } from "@/lib/chess/classify";
import { UciEngine } from "@/lib/chess/engine";
import { moverWin, terminalScore, uciToSanLine } from "@/lib/chess/eval";
import { toNode } from "@/lib/chess/pgn";
import type { EngineResult, Game, MoveNode } from "@/lib/chess/types";
import type { HunterFinding, HunterScanControl, HunterScanOptions, SignalLevel } from "./types";

const id = () =>
  globalThis.crypto?.randomUUID?.() ??
  `discovery-${Date.now()}-${Math.random().toString(36).slice(2)}`;

function signal(level: number): SignalLevel {
  return level >= 2 ? "High" : level === 1 ? "Medium" : "Low";
}

function tacticalComplexity(move: MoveNode, continuation: string[]): SignalLevel {
  const forcingCount = continuation.slice(0, 8).filter((san) => /[+#x]/.test(san)).length;
  const choices = new Chess(move.fenBefore).moves().length;
  return signal((forcingCount >= 3 ? 1 : 0) + (choices >= 30 ? 1 : 0));
}

function difficulty(move: MoveNode, before: EngineResult, bestMove?: string): SignalLevel {
  const legalCount = new Chess(move.fenBefore).moves().length;
  const first = before.lines[0]?.pv[0];
  const bestGap =
    before.lines.length > 1
      ? Math.abs(
          moverWin(before.lines[0].score, move.color) - moverWin(before.lines[1].score, move.color),
        )
      : 0;
  const nonForcing = !/[+#x]/.test(move.san);
  return signal(
    (legalCount >= 30 ? 1 : 0) + (nonForcing && bestMove === first ? 1 : 0) + (bestGap < 3 ? 1 : 0),
  );
}

/**
 * Converts actual engine lines into a conservative Hunter finding. A high-looking move is not
 * called confirmed unless the played move is engine-best and both sides' positions were searched
 * deeply with multiple candidate/defense lines available.
 */
export function scoreHunterMove(
  move: MoveNode,
  before: EngineResult,
  after: EngineResult,
  candidateCount = before.lines.length,
): HunterFinding | null {
  const beforeTerminal = terminalScore(move.fenBefore);
  const afterTerminal = terminalScore(move.fenAfter);
  const review = classifyMove(move, before, beforeTerminal, after, afterTerminal, false);
  const sacrifice = detectMaterialSacrifice(move);
  const bestUci = before.lines[0]?.pv[0];
  const bestMove = bestUci ? uciToSanLine(move.fenBefore, [bestUci], 1)[0] : undefined;
  const bestOpponentResponse = after.lines[0]?.pv[0]
    ? uciToSanLine(move.fenAfter, after.lines[0].pv, 1)[0]
    : undefined;
  const depth = Math.min(before.depth, after.depth);
  const sufficientlyDeep = depth >= 20 && before.lines.length >= 3 && after.lines.length >= 2;
  const isBest = bestUci === move.uci;
  const rawClass = review?.classification;
  const secondLine = before.lines[1];
  const bestGap = secondLine
    ? moverWin(before.lines[0].score, move.color) - moverWin(secondLine.score, move.color)
    : 0;
  const forcingMove = /[x+#]/.test(move.san);
  let classification: HunterFinding["classification"];

  if (rawClass === "brilliant")
    classification = sufficientlyDeep ? "Confirmed Brilliant" : "Needs Deeper Analysis";
  else if (rawClass === "great") classification = "Strong Candidate";
  else if (sacrifice && (rawClass === "blunder" || rawClass === "mistake"))
    classification = "Refuted";
  else if (sacrifice && isBest && (rawClass === "excellent" || rawClass === "best"))
    classification = "Speculative";
  else if (sacrifice) classification = "Needs Deeper Analysis";
  else if (
    isBest &&
    (rawClass === "best" || rawClass === "excellent") &&
    (bestGap >= 5 || forcingMove)
  )
    classification = "Interesting";
  else return null;

  const confidence =
    depth >= 20 && before.lines.length >= 3 && after.lines.length >= 2
      ? "High"
      : depth >= 16 && before.lines.length >= 2
        ? "Moderate"
        : "Low — provisional";
  const verified = classification === "Confirmed Brilliant" && confidence === "High";
  const loss =
    review?.winLoss ??
    Math.max(
      0,
      moverWin(before.lines[0].score, move.color) - moverWin(after.lines[0].score, move.color),
    );
  const mainVariation = review?.bestPvSan?.length
    ? review.bestPvSan
    : uciToSanLine(move.fenBefore, before.lines[0]?.pv ?? [], 10);
  const explanation = verified
    ? (review?.explanation ??
      `${move.san} is the engine's top candidate after a material investment; the best searched defense is ${bestOpponentResponse ?? "not available"}.`)
    : classification === "Refuted"
      ? `${move.san} is not supported by the current best-response search${bestOpponentResponse ? `; the strongest searched reply is ${bestOpponentResponse}` : ""}. This is an engine-based refutation at depth ${depth}, not a proof beyond that search. `
      : (review?.explanation ??
        `Engine comparison at depth ${depth}: ${bestMove ? `top move ${bestMove}` : "best move unavailable"}; the result remains ${classification.toLowerCase()} until deeper opponent-response verification.`);

  return {
    id: id(),
    discoveredAt: new Date().toISOString(),
    ply: move.ply,
    moveNumber: move.moveNumber,
    actualMove: move.san,
    actualMoveUci: move.uci,
    color: move.color,
    fenBefore: move.fenBefore,
    fenAfter: move.fenAfter,
    classification,
    confidence,
    verified,
    engineDepth: depth,
    candidateCount,
    before: beforeTerminal ?? before.lines[0].score,
    after: afterTerminal ?? after.lines[0].score,
    winChanceLoss: loss,
    bestMove,
    bestMoveUci: bestUci,
    bestOpponentResponse,
    mainVariation,
    materialSacrifice: sacrifice?.piece,
    tacticalComplexity: tacticalComplexity(move, mainVariation),
    discoveryDifficulty: difficulty(move, before, bestMove),
    explanation,
  };
}

async function waitIfPaused(control: HunterScanControl) {
  while (!control.isCancelled()) await control.waitWhilePaused();
}

export async function scanGame(
  game: Game,
  engine: UciEngine,
  options: HunterScanOptions,
  control: HunterScanControl,
): Promise<HunterFinding[]> {
  const started = performance.now();
  const moves = game.moves.slice(0, Math.max(1, Math.min(120, options.maxMoves)));
  const found: HunterFinding[] = [];
  for (let i = 0; i < moves.length; i++) {
    if (control.isCancelled()) break;
    await waitIfPaused(control);
    if (control.isCancelled()) break;
    const move = moves[i];
    const before = await engine.analyze(move.fenBefore, options.depth, options.candidateCount);
    if (control.isCancelled()) break;
    if (before) {
      const after = await engine.analyze(move.fenAfter, options.depth, 2);
      if (control.isCancelled()) break;
      if (after) {
        const finding = scoreHunterMove(move, before, after, before.lines.length);
        if (finding) {
          finding.gameMeta = {
            white: game.meta.white,
            black: game.meta.black,
            event: game.meta.event,
            date: game.meta.date,
          };
          finding.sourcePgn = game.sourcePgn;
          found.push(finding);
        }
      }
    }
    control.onProgress({
      done: i + 1,
      total: moves.length,
      candidates: found.length,
      currentMove: `${move.moveNumber}${move.color === "w" ? "." : "…"} ${move.san}`,
      elapsedMs: performance.now() - started,
    });
  }
  return found;
}

export async function scanPosition(
  fen: string,
  engine: UciEngine,
  depth: number,
  candidateCount: number,
  isCancelled: () => boolean = () => false,
): Promise<HunterFinding[]> {
  const chess = new Chess(fen);
  const before = await engine.analyze(fen, depth, Math.max(1, Math.min(8, candidateCount)));
  if (!before || isCancelled()) return [];
  const findings: HunterFinding[] = [];
  const byUci = new Map(before.lines.map((line) => [line.pv[0], line]));
  const candidates = [...byUci.keys()].filter(
    (uci): uci is string => !!uci && /^[a-h][1-8][a-h][1-8][qrbn]?$/.test(uci),
  );
  for (const uci of candidates) {
    if (isCancelled()) break;
    const c = new Chess(fen);
    try {
      const mv = c.move({
        from: uci.slice(0, 2) as Square,
        to: uci.slice(2, 4) as Square,
        promotion: uci[4],
      });
      const move = toNode(mv, 0);
      const after = await engine.analyze(move.fenAfter, depth, 2);
      if (after && !isCancelled()) {
        const finding = scoreHunterMove(move, before, after, candidates.length);
        if (finding) findings.push(finding);
      }
    } catch {
      // Ignore malformed engine PVs; they cannot become user-visible discoveries.
    }
  }
  return findings.sort(
    (a, b) => Number(b.verified) - Number(a.verified) || a.winChanceLoss - b.winChanceLoss,
  );
}
