import { Chess, type Square } from "chess.js";
import { moverWin } from "@/lib/chess/eval";
import type { PvLine, Score } from "@/lib/chess/types";
import type { UciSearchOptions } from "@/lib/chess/engine";

export type BotDifficulty =
  | "beginner"
  | "casual"
  | "intermediate"
  | "advanced"
  | "expert"
  | "master"
  | "grandmaster"
  | "ultimate";

export type BotPersonality =
  "balanced" | "aggressive" | "defensive" | "tactical" | "positional" | "endgame" | "brilliant";

export interface BotProfile {
  id: BotDifficulty;
  label: string;
  depth: number;
  strength: UciSearchOptions;
  note: string;
}

/** UCI_Elo is a Stockfish control target, not a calibrated player Elo. */
export const BOT_PROFILES: BotProfile[] = [
  {
    id: "beginner",
    label: "Beginner",
    depth: 8,
    strength: { limitStrength: true, elo: 1320, skillLevel: 0 },
    note: "Lowest supported Stockfish limit",
  },
  {
    id: "casual",
    label: "Casual",
    depth: 10,
    strength: { limitStrength: true, elo: 1500, skillLevel: 4 },
    note: "Limited engine strength",
  },
  {
    id: "intermediate",
    label: "Intermediate",
    depth: 12,
    strength: { limitStrength: true, elo: 1800, skillLevel: 8 },
    note: "Limited engine strength",
  },
  {
    id: "advanced",
    label: "Advanced",
    depth: 14,
    strength: { limitStrength: true, elo: 2200, skillLevel: 12 },
    note: "Limited engine strength",
  },
  {
    id: "expert",
    label: "Expert",
    depth: 16,
    strength: { limitStrength: true, elo: 2600, skillLevel: 16 },
    note: "Limited engine strength",
  },
  {
    id: "master",
    label: "Master",
    depth: 18,
    strength: { limitStrength: true, elo: 2900, skillLevel: 20 },
    note: "High engine limit; uncalibrated",
  },
  {
    id: "grandmaster",
    label: "Grandmaster",
    depth: 20,
    strength: { limitStrength: true, elo: 3190, skillLevel: 20 },
    note: "Maximum configured UCI strength limit",
  },
  {
    id: "ultimate",
    label: "Ultimate Engine",
    depth: 22,
    strength: { limitStrength: false, skillLevel: 20 },
    note: "Unrestricted Stockfish; device load may vary",
  },
];

export const PERSONALITIES: { id: BotPersonality; label: string; description: string }[] = [
  {
    id: "balanced",
    label: "Balanced Player",
    description: "Chooses the strongest line found by Stockfish.",
  },
  {
    id: "aggressive",
    label: "Aggressive Attacker",
    description: "Experimental: prefers forcing captures and checks among near-equal engine lines.",
  },
  {
    id: "defensive",
    label: "Defensive Player",
    description: "Experimental: prefers safer destinations among near-equal lines.",
  },
  {
    id: "tactical",
    label: "Tactical Specialist",
    description: "Experimental: favors checks, captures and promotions among near-equal lines.",
  },
  {
    id: "positional",
    label: "Positional Strategist",
    description: "Experimental: prefers quiet piece moves among near-equal lines.",
  },
  {
    id: "endgame",
    label: "Endgame Specialist",
    description: "Experimental: uses king activity and pawn progress in simplified positions.",
  },
  {
    id: "brilliant",
    label: "Brilliant Search",
    description:
      "Experimental: searches all legal first moves (up to 8 seconds) and prefers a tactical line only when it stays near Stockfish's best score; this is not a verified-brilliant label.",
  },
];

const PV_PREFIX = /^[a-h][1-8][a-h][1-8][qrbn]?$/;

function firstMove(fen: string, uci: string) {
  if (!PV_PREFIX.test(uci)) return null;
  const chess = new Chess(fen);
  try {
    return {
      chess,
      move: chess.move({
        from: uci.slice(0, 2) as Square,
        to: uci.slice(2, 4) as Square,
        promotion: uci[4],
      }),
    };
  } catch {
    return null;
  }
}

function scoreForSide(score: Score, color: "w" | "b") {
  return moverWin(score, color);
}

/** Selects only from engine-returned legal PVs; experimental style heuristics cannot exceed the score tolerance. */
export function selectBotLine(
  fen: string,
  color: "w" | "b",
  lines: PvLine[],
  personality: BotPersonality,
): PvLine | null {
  if (!lines.length) return null;
  const ranked = lines
    .map((line) => ({
      line,
      score: scoreForSide(line.score, color),
      parsed: firstMove(fen, line.pv[0] ?? ""),
    }))
    .filter((candidate) => candidate.parsed)
    .sort((a, b) => b.score - a.score);
  if (!ranked.length) return null;
  const best = ranked[0];
  if (personality === "balanced" || ranked.length === 1) return best.line;

  const nearBest = ranked.filter((candidate) => best.score - candidate.score <= 2.5);
  const board = new Chess(fen);
  const pieces = board.board().flat().filter(Boolean).length;
  const enemy = color === "w" ? "b" : "w";
  const preference = (candidate: (typeof ranked)[number]) => {
    const { chess, move } = candidate.parsed!;
    let value = 0;
    const givesCheck = move.san.includes("+") || move.san.includes("#");
    const capture = !!move.captured;
    const promotion = !!move.promotion;
    const type = board.get(move.from as Square)?.type;

    if (personality === "aggressive")
      value += (capture ? 1.5 : 0) + (givesCheck ? 2 : 0) + (promotion ? 3 : 0);
    if (personality === "tactical")
      value += (capture ? 1.5 : 0) + (givesCheck ? 2.5 : 0) + (promotion ? 2 : 0);
    if (personality === "positional")
      value += (!capture && type !== "p" ? 1.5 : 0) + (givesCheck ? 0.3 : 0);
    if (personality === "defensive") {
      const moved = chess.get(move.to as Square);
      if (moved) {
        const attackers = chess.attackers(move.to as Square, enemy);
        const defenders = chess.attackers(move.to as Square, color);
        value += attackers.length === 0 ? 1.3 : defenders.length >= attackers.length ? 0.4 : -1.4;
      }
    }
    if (personality === "endgame") {
      if (pieces <= 12) {
        value += promotion ? 3 : 0;
        if (type === "p")
          value += color === "w" ? Number(move.to[1]) / 8 : (9 - Number(move.to[1])) / 8;
        if (type === "k") {
          const file = move.to.charCodeAt(0) - 96;
          const rank = Number(move.to[1]);
          value += 1 - (Math.abs(file - 4.5) + Math.abs(rank - 4.5)) / 8;
        }
      }
    }
    return value;
  };

  return nearBest.sort((a, b) => preference(b) - preference(a) || b.score - a.score)[0].line;
}
