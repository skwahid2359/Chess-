import { Chess, type Move } from "chess.js";
import { detectMaterialSacrifice } from "@/lib/chess/classify";
import { moverWin } from "@/lib/chess/eval";
import { toNode } from "@/lib/chess/pgn";
import type { PvLine } from "@/lib/chess/types";

const UCI_MOVE = /^[a-h][1-8][a-h][1-8][qrbn]?$/;
export const BRILLIANT_SCORE_TOLERANCE = 2.5;

export type BrilliantSearchPick = {
  line: PvLine | null;
  legalMoveCount: number;
  coveredMoveCount: number;
  completeCoverage: boolean;
  scoreComparable: boolean;
  choseTacticalAlternative: boolean;
};

function legalMoveMap(fen: string) {
  const chess = new Chess(fen);
  const moves = chess.moves({ verbose: true });
  return new Map(moves.map((move) => [moveToUci(move), move]));
}

function moveToUci(move: Move) {
  return move.from + move.to + (move.promotion ?? "");
}

/** Count distinct legal root moves that Stockfish actually returned a PV for. */
export function countCoveredLegalMoves(fen: string, lines: PvLine[]) {
  const legalMoves = legalMoveMap(fen);
  const covered = new Set(
    lines.map((line) => line.pv[0]).filter((uci) => !!uci && legalMoves.has(uci)),
  );
  return { legalMoveCount: legalMoves.size, coveredMoveCount: covered.size };
}

function tacticalPriority(move: Move) {
  const moveNode = toNode(move, 0);
  const sacrifice = detectMaterialSacrifice(moveNode);
  // This is a tactical signal, not a claim that Hunter verified a brilliant move.
  return (
    (sacrifice && sacrifice.piece !== "pawn" ? 4 : sacrifice ? 2 : 0) +
    (move.san.includes("+") || move.san.includes("#") ? 2 : 0) +
    (move.captured ? 1 : 0) +
    (move.promotion ? 2 : 0)
  );
}

/**
 * Only when every legal root move has a returned engine PV, prefer a tactical signature that is
 * within a small win-probability tolerance of Stockfish's best move. If coverage is incomplete,
 * use the best move among the searched lines instead of extrapolating to unseen legal moves.
 */
export function selectBrilliantSearchLine(
  fen: string,
  color: "w" | "b",
  lines: PvLine[],
): BrilliantSearchPick {
  const legalMoves = legalMoveMap(fen);
  const legalMoveCount = legalMoves.size;
  const byUci = new Map<string, PvLine>();
  for (const line of lines) {
    const uci = line.pv[0];
    if (uci && UCI_MOVE.test(uci) && legalMoves.has(uci) && !byUci.has(uci)) byUci.set(uci, line);
  }
  const candidates = [...byUci.entries()].map(([uci, line]) => ({
    uci,
    line,
    score: moverWin(line.score, color),
    move: legalMoves.get(uci)!,
  }));
  if (!candidates.length)
    return {
      line: null,
      legalMoveCount,
      coveredMoveCount: 0,
      completeCoverage: legalMoveCount === 0,
      scoreComparable: false,
      choseTacticalAlternative: false,
    };

  const bestScore = Math.max(...candidates.map((candidate) => candidate.score));
  const best = candidates.find((candidate) => candidate.score === bestScore)!;
  const completeCoverage = legalMoveCount > 0 && candidates.length === legalMoveCount;
  const scoreComparable = new Set(candidates.map((candidate) => candidate.line.depth)).size === 1;
  if (!completeCoverage || !scoreComparable)
    return {
      line: best.line,
      legalMoveCount,
      coveredMoveCount: candidates.length,
      completeCoverage,
      scoreComparable,
      choseTacticalAlternative: false,
    };

  const nearBest = candidates.filter(
    (candidate) => bestScore - candidate.score <= BRILLIANT_SCORE_TOLERANCE,
  );
  const tactical = nearBest
    .map((candidate) => ({ ...candidate, priority: tacticalPriority(candidate.move) }))
    .filter((candidate) => candidate.priority > 0)
    .sort((a, b) => b.priority - a.priority || b.score - a.score);
  const selected = tactical[0] ?? best;
  return {
    line: selected.line,
    legalMoveCount,
    coveredMoveCount: candidates.length,
    completeCoverage: true,
    scoreComparable: true,
    choseTacticalAlternative: selected.uci !== best.uci,
  };
}
