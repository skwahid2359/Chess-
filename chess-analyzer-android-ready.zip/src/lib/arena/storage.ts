import type { BotGameRecord, HunterFinding } from "./types";

const DB_NAME = "chess-insights-arena";
const DB_VERSION = 1;
const DISCOVERY_STORE = "verifiedDiscoveries";
const GAME_STORE = "botGames";
const FALLBACK_LIMIT = 80;

function openDb(): Promise<IDBDatabase | null> {
  if (typeof indexedDB === "undefined") return Promise.resolve(null);
  return new Promise((resolve) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(DISCOVERY_STORE))
        db.createObjectStore(DISCOVERY_STORE, { keyPath: "id" });
      if (!db.objectStoreNames.contains(GAME_STORE))
        db.createObjectStore(GAME_STORE, { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => resolve(null);
    request.onblocked = () => resolve(null);
  });
}

function fallbackRead<T>(key: string): T[] {
  try {
    const value = JSON.parse(localStorage.getItem(key) ?? "[]");
    return Array.isArray(value) ? (value as T[]) : [];
  } catch {
    return [];
  }
}

function fallbackWrite<T extends { id: string }>(key: string, record: T) {
  try {
    const all = fallbackRead<T>(key).filter((item) => item.id !== record.id);
    localStorage.setItem(key, JSON.stringify([record, ...all].slice(0, FALLBACK_LIMIT)));
  } catch {
    // Storage may be unavailable or quota-limited; the current in-memory result still remains usable.
  }
}

function idbRequest<T>(
  db: IDBDatabase,
  store: string,
  mode: IDBTransactionMode,
  operation: (os: IDBObjectStore) => IDBRequest<T>,
): Promise<T | null> {
  return new Promise((resolve) => {
    try {
      const request = operation(db.transaction(store, mode).objectStore(store));
      request.onsuccess = () => resolve(request.result ?? null);
      request.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

export async function saveVerifiedDiscovery(finding: HunterFinding): Promise<boolean> {
  if (!finding.verified || finding.classification !== "Confirmed Brilliant") return false;
  const db = await openDb();
  if (!db) {
    fallbackWrite("chess-arena-verified-discoveries-v1", finding);
    return true;
  }
  const result = await idbRequest(db, DISCOVERY_STORE, "readwrite", (store) => store.put(finding));
  db.close();
  return result !== null;
}

export async function listVerifiedDiscoveries(): Promise<HunterFinding[]> {
  const db = await openDb();
  if (!db) return fallbackRead<HunterFinding>("chess-arena-verified-discoveries-v1");
  const result = await idbRequest(db, DISCOVERY_STORE, "readonly", (store) => store.getAll());
  db.close();
  return Array.isArray(result) ? (result as HunterFinding[]) : [];
}

export async function deleteVerifiedDiscovery(id: string): Promise<void> {
  const db = await openDb();
  if (!db) {
    try {
      localStorage.setItem(
        "chess-arena-verified-discoveries-v1",
        JSON.stringify(
          fallbackRead<HunterFinding>("chess-arena-verified-discoveries-v1").filter(
            (item) => item.id !== id,
          ),
        ),
      );
    } catch {
      /* ignore unavailable storage */
    }
    return;
  }
  await idbRequest(db, DISCOVERY_STORE, "readwrite", (store) => store.delete(id));
  db.close();
}

export async function saveBotGame(record: BotGameRecord): Promise<void> {
  const db = await openDb();
  if (!db) {
    fallbackWrite("chess-arena-bot-games-v1", record);
    return;
  }
  await idbRequest(db, GAME_STORE, "readwrite", (store) => store.put(record));
  db.close();
}

export async function listBotGames(): Promise<BotGameRecord[]> {
  const db = await openDb();
  if (!db) return fallbackRead<BotGameRecord>("chess-arena-bot-games-v1");
  const result = await idbRequest(db, GAME_STORE, "readonly", (store) => store.getAll());
  db.close();
  return Array.isArray(result) ? (result as BotGameRecord[]) : [];
}

export async function deleteBotGame(id: string): Promise<void> {
  const db = await openDb();
  if (!db) {
    try {
      localStorage.setItem(
        "chess-arena-bot-games-v1",
        JSON.stringify(
          fallbackRead<BotGameRecord>("chess-arena-bot-games-v1").filter((item) => item.id !== id),
        ),
      );
    } catch {
      /* ignore unavailable storage */
    }
    return;
  }
  await idbRequest(db, GAME_STORE, "readwrite", (store) => store.delete(id));
  db.close();
}
