import type { Game, MoveNode, Score } from "@/lib/chess/types";

export type HunterClassification =
  | "Confirmed Brilliant"
  | "Strong Candidate"
  | "Interesting"
  | "Speculative"
  | "Refuted"
  | "Needs Deeper Analysis";

export type ConfidenceLevel = "High" | "Moderate" | "Low — provisional";
export type SignalLevel = "Low" | "Medium" | "High";

export interface HunterFinding {
  id: string;
  discoveredAt: string;
  ply: number;
  moveNumber: number;
  actualMove: string;
  actualMoveUci: string;
  color: "w" | "b";
  fenBefore: string;
  fenAfter: string;
  classification: HunterClassification;
  confidence: ConfidenceLevel;
  verified: boolean;
  engineDepth: number;
  candidateCount: number;
  sourcePgn?: string;
  before: Score;
  after: Score;
  winChanceLoss: number;
  bestMove?: string;
  bestMoveUci?: string;
  bestOpponentResponse?: string;
  mainVariation: string[];
  materialSacrifice?: string;
  tacticalComplexity: SignalLevel;
  discoveryDifficulty: SignalLevel;
  explanation: string;
  gameMeta?: { white: string; black: string; event?: string; date?: string };
}

export interface HunterScanOptions {
  depth: number;
  maxMoves: number;
  candidateCount: number;
}

export interface HunterScanProgress {
  done: number;
  total: number;
  candidates: number;
  currentMove?: string;
  elapsedMs: number;
}

export interface HunterScanControl {
  isCancelled: () => boolean;
  waitWhilePaused: () => Promise<void>;
  onProgress: (progress: HunterScanProgress) => void;
}

export interface BotGameRecord {
  id: string;
  createdAt: string;
  result: string;
  white: string;
  black: string;
  pgn: string;
  difficulty: string;
  personality: string;
  moveCount: number;
}

export interface VerifiedPuzzle {
  finding: HunterFinding;
  game: Game;
  sourceMove: MoveNode;
}
