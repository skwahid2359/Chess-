import type { HunterFinding } from "./types";

/** Canonicalizes the board from the side-to-move perspective, allowing color/rank-flipped patterns to compare. */
export function positionFeatures(fen: string): Set<string> {
  const [boardPart = "", turn = "w"] = fen.split(" ");
  const features = new Set<string>([`turn:${turn}`]);
  const rows = boardPart.split("/");
  let material = 0;
  const values: Record<string, number> = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
  rows.forEach((row, rowIndex) => {
    let file = 0;
    for (const ch of row) {
      if (/\d/.test(ch)) {
        file += Number(ch);
        continue;
      }
      const color = ch === ch.toUpperCase() ? "w" : "b";
      const piece = ch.toLowerCase();
      const relativeSide = color === turn ? "us" : "them";
      const rank = turn === "w" ? 7 - rowIndex : rowIndex;
      const canonicalFile = Math.min(file, 7 - file);
      features.add(
        `piece:${relativeSide}:${piece}:rank${Math.min(3, Math.floor(rank / 2))}:fileband${canonicalFile}`,
      );
      if (piece === "p")
        features.add(`pawn:${relativeSide}:file${canonicalFile}:rank${Math.floor(rank / 2)}`);
      material += (relativeSide === "us" ? 1 : -1) * (values[piece] ?? 0);
      file++;
    }
  });
  features.add(`material:${material >= 3 ? "us-up" : material <= -3 ? "them-up" : "balanced"}`);
  return features;
}

export function patternTags(finding: HunterFinding): string[] {
  const tags = new Set<string>();
  if (finding.materialSacrifice) tags.add(`sacrifice:${finding.materialSacrifice.toLowerCase()}`);
  if (finding.actualMove.includes("x")) tags.add("move:capture");
  if (finding.actualMove.includes("+")) tags.add("move:check");
  if (finding.actualMove.includes("#")) tags.add("motif:mating-move");
  if (
    !finding.actualMove.includes("x") &&
    !finding.actualMove.includes("+") &&
    !finding.actualMove.includes("#")
  )
    tags.add("move:quiet");
  if (finding.tacticalComplexity === "High") tags.add("complexity:high");
  tags.add(`confidence:${finding.confidence}`);
  return [...tags];
}

export interface SimilarPattern {
  finding: HunterFinding;
  sharedFeatures: number;
  overlap: number;
  sharedTags: string[];
}

/** Jaccard-style structural overlap plus explicit tag overlap; this is a search signal, not proof of the same tactic. */
export function findSimilarPatterns(
  target: HunterFinding,
  records: HunterFinding[],
  limit = 12,
): SimilarPattern[] {
  const targetFeatures = positionFeatures(target.fenBefore);
  const targetTags = new Set(patternTags(target));
  return records
    .filter((record) => record.id !== target.id && record.verified)
    .map((finding) => {
      const features = positionFeatures(finding.fenBefore);
      const sharedFeatures = [...targetFeatures].filter((feature) => features.has(feature)).length;
      const union = new Set([...targetFeatures, ...features]).size;
      const sharedTags = patternTags(finding).filter((tag) => targetTags.has(tag));
      const overlap = union ? sharedFeatures / union : 0;
      return { finding, sharedFeatures, overlap: Math.round(overlap * 100), sharedTags };
    })
    .sort((a, b) => b.overlap - a.overlap || b.sharedTags.length - a.sharedTags.length)
    .slice(0, limit);
}
