import { useEffect, useState } from "react";
import { BotGame } from "./BotGame";
import { HunterWorkspace } from "./HunterWorkspace";
import { DNAExplorer } from "./DNAExplorer";
import { PuzzleWorkspace } from "./PuzzleWorkspace";
import { BenchmarkDashboard } from "./BenchmarkDashboard";
import { deleteBotGame, listBotGames, listVerifiedDiscoveries } from "@/lib/arena/storage";
import type { BotGameRecord, HunterFinding } from "@/lib/arena/types";

type ArenaView =
  "home" | "play" | "hunter" | "lab" | "dna" | "human" | "training" | "benchmark" | "games";
const NAV: { id: ArenaView; label: string }[] = [
  { id: "home", label: "Overview" },
  { id: "play", label: "Play Bots" },
  { id: "hunter", label: "Brilliant Hunter" },
  { id: "lab", label: "Discovery Lab" },
  { id: "dna", label: "DNA Explorer" },
  { id: "human", label: "Human vs Hunter" },
  { id: "training", label: "Training" },
  { id: "benchmark", label: "Benchmark" },
  { id: "games", label: "Game History" },
];

export function BotArena({ onBack }: { onBack: () => void }) {
  const [view, setView] = useState<ArenaView>("home");
  const [games, setGames] = useState<BotGameRecord[]>([]);
  const [discoveries, setDiscoveries] = useState<HunterFinding[]>([]);
  const refresh = () => {
    void listBotGames().then((rows) =>
      setGames(rows.sort((a, b) => b.createdAt.localeCompare(a.createdAt))),
    );
    void listVerifiedDiscoveries().then((rows) =>
      setDiscoveries(rows.filter((item) => item.verified)),
    );
  };
  useEffect(() => {
    refresh();
  }, []);
  useEffect(() => {
    if (view === "games" || view === "home" || view === "dna") refresh();
  }, [view]);

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-20 border-b bg-background/95 px-3 py-2 backdrop-blur sm:px-5">
        <div className="flex items-center gap-3">
          <span className="font-mono font-bold text-primary">♜</span>
          <div>
            <div className="text-sm font-bold tracking-wide">BOT ARENA</div>
            <div className="text-[10px] text-muted-foreground">
              Stockfish-powered play and verified chess discovery
            </div>
          </div>
          <span className="ml-auto hidden rounded border px-2 py-1 text-[10px] text-muted-foreground sm:inline">
            Engine assets · Stockfish 19 Lite WASM
          </span>
          <button onClick={onBack} className="rounded border px-3 py-1.5 text-xs hover:bg-accent">
            Analyzer
          </button>
        </div>
        <nav aria-label="Bot Arena navigation" className="mt-2 flex gap-1 overflow-x-auto pb-1">
          {NAV.map((item) => (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              aria-current={view === item.id ? "page" : undefined}
              className={`shrink-0 rounded px-2.5 py-1.5 text-xs ${view === item.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent hover:text-foreground"}`}
            >
              {item.label}
            </button>
          ))}
        </nav>
      </header>

      <main className="mx-auto flex w-full max-w-[1400px] flex-col gap-4 p-3 sm:p-5">
        {view === "home" && (
          <ArenaHome games={games} discoveries={discoveries} onSelect={setView} />
        )}
        {view === "play" && <BotGame />}
        {view === "hunter" && <HunterWorkspace mode="game" />}
        {view === "lab" && <HunterWorkspace mode="position" />}
        {view === "dna" && <DNAExplorer />}
        {view === "human" && <PuzzleWorkspace mode="human" />}
        {view === "training" && <PuzzleWorkspace mode="training" />}
        {view === "benchmark" && <BenchmarkDashboard />}
        {view === "games" && <GameHistory games={games} onRefresh={refresh} />}
      </main>
    </div>
  );
}

function ArenaHome({
  games,
  discoveries,
  onSelect,
}: {
  games: BotGameRecord[];
  discoveries: HunterFinding[];
  onSelect: (view: ArenaView) => void;
}) {
  const cards: { view: ArenaView; title: string; body: string; accent?: string }[] = [
    {
      view: "play",
      title: "Play Against Bots",
      body: "Choose a side, strength profile, time control and playing style.",
    },
    {
      view: "hunter",
      title: "Brilliant Hunter",
      body: "Scan a PGN using real engine candidates and best-response checks.",
      accent: "text-cls-brilliant",
    },
    {
      view: "lab",
      title: "Discovery Lab",
      body: "Investigate a FEN and compare engine candidate moves.",
    },
    {
      view: "dna",
      title: "Brilliant Move DNA",
      body: "Browse verified records and compare normalized tactical structures.",
    },
    {
      view: "human",
      title: "Human vs Hunter",
      body: "Try a verified discovery before revealing the engine line.",
    },
    {
      view: "training",
      title: "Brilliant Training",
      body: "Practice puzzles sourced only from verified records.",
    },
    {
      view: "benchmark",
      title: "Discovery Benchmark",
      body: "Import attributed positions and compute metrics from actual runs.",
    },
  ];
  return (
    <>
      <section className="panel flex flex-wrap items-center gap-3 p-3 sm:p-4">
        <div className="min-w-0 flex-1">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-primary">
            Chess Insights Engine · Bot Arena
          </div>
          <h1 className="mt-1 text-lg font-semibold tracking-tight sm:text-xl">
            Play bots and investigate positions
          </h1>
          <p className="mt-1 max-w-3xl text-xs leading-relaxed text-muted-foreground">
            Stockfish-powered games and evidence-based discovery. Unverified findings stay
            provisional; the existing Analyzer remains available from the top navigation.
          </p>
        </div>
        <button
          onClick={() => onSelect("play")}
          className="rounded-md bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground hover:opacity-90"
        >
          Start a bot game
        </button>
      </section>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {cards.map((card) => (
          <button
            key={card.view}
            onClick={() => onSelect(card.view)}
            className="panel flex min-h-32 flex-col p-4 text-left transition-colors hover:border-primary/40 hover:bg-panel-raised"
          >
            <span className={`text-sm font-semibold ${card.accent ?? ""}`}>{card.title}</span>
            <span className="mt-2 text-xs leading-relaxed text-muted-foreground">{card.body}</span>
            <span className="mt-auto pt-3 text-[10px] text-primary">Open workspace →</span>
          </button>
        ))}
      </div>
      <div className="grid gap-3 md:grid-cols-3">
        <div className="panel p-4">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
            Recent Bot Games
          </div>
          <div className="mt-1 text-2xl font-semibold">{games.length}</div>
          <button
            onClick={() => onSelect("games")}
            className="mt-2 text-xs text-primary hover:underline"
          >
            Open game history
          </button>
        </div>
        <div className="panel p-4">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
            Verified Discoveries
          </div>
          <div className="mt-1 text-2xl font-semibold text-cls-brilliant">{discoveries.length}</div>
          <button
            onClick={() => onSelect("dna")}
            className="mt-2 text-xs text-primary hover:underline"
          >
            Open DNA Explorer
          </button>
        </div>
        <div className="panel p-4">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
            Engine Status
          </div>
          <div className="mt-1 text-sm font-semibold">Idle · ready on demand</div>
          <p className="mt-2 text-[10px] text-muted-foreground">
            Stockfish 19 Lite · single-thread Web Worker/WASM · engine starts only inside a tool to
            limit device load.
          </p>
        </div>
      </div>
      <section className="panel p-4">
        <h2 className="text-sm font-semibold">Recent games</h2>
        {games.length ? (
          <div className="mt-2 flex flex-col gap-2">
            {games.slice(0, 5).map((game) => (
              <div
                className="flex flex-wrap items-center gap-2 border-t pt-2 text-xs"
                key={game.id}
              >
                <span>
                  {game.white} – {game.black}
                </span>
                <span className="text-muted-foreground">
                  {game.result} · {game.moveCount} ply ·{" "}
                  {new Date(game.createdAt).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <p className="mt-2 text-xs text-muted-foreground">No completed bot games saved yet.</p>
        )}
      </section>
    </>
  );
}

function GameHistory({ games, onRefresh }: { games: BotGameRecord[]; onRefresh: () => void }) {
  const [message, setMessage] = useState("");
  const download = (game: BotGameRecord) => {
    const url = URL.createObjectURL(new Blob([game.pgn], { type: "application/x-chess-pgn" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `bot-game-${game.id}.pgn`;
    a.click();
    URL.revokeObjectURL(url);
  };
  const remove = async (id: string) => {
    await deleteBotGame(id);
    onRefresh();
    setMessage("Game removed from this device.");
  };
  return (
    <section className="flex flex-col gap-3">
      <div>
        <h2 className="text-xl font-semibold">Recent Bot Games</h2>
        <p className="text-xs text-muted-foreground">
          Stored locally on this device. Export PGN or delete individual games.
        </p>
      </div>
      {message && (
        <p role="status" className="text-xs text-muted-foreground">
          {message}
        </p>
      )}
      {games.length ? (
        games.map((game) => (
          <article key={game.id} className="panel flex flex-wrap items-center gap-3 p-3">
            <div className="min-w-0 flex-1">
              <div className="font-semibold">
                {game.white} <span className="text-muted-foreground">vs</span> {game.black}{" "}
                <span className="ml-2 font-mono text-primary">{game.result}</span>
              </div>
              <div className="mt-1 text-[10px] text-muted-foreground">
                {new Date(game.createdAt).toLocaleString()} · {game.moveCount} plies ·{" "}
                {game.difficulty} · {game.personality}
              </div>
            </div>
            <button onClick={() => download(game)} className="rounded border px-3 py-1.5 text-xs">
              Export PGN
            </button>
            <button
              onClick={() => void remove(game.id)}
              className="rounded border border-destructive/40 px-3 py-1.5 text-xs text-destructive"
            >
              Delete
            </button>
          </article>
        ))
      ) : (
        <div className="panel p-5 text-sm text-muted-foreground">
          No saved games yet. Complete a bot game to see it here.
        </div>
      )}
    </section>
  );
}
