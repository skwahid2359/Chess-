import { useEffect, useMemo, useState } from "react";
import { deleteVerifiedDiscovery, listVerifiedDiscoveries } from "@/lib/arena/storage";
import { findSimilarPatterns, patternTags } from "@/lib/arena/dna";
import type { HunterFinding } from "@/lib/arena/types";

function download(name: string, text: string, type: string) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const link = document.createElement("a");
  link.href = url;
  link.download = name;
  link.click();
  URL.revokeObjectURL(url);
}

export function DNAExplorer() {
  const [records, setRecords] = useState<HunterFinding[]>([]);
  const [selected, setSelected] = useState<HunterFinding | null>(null);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  useEffect(() => {
    void listVerifiedDiscoveries().then((rows) => {
      const verified = rows.filter(
        (row) => row.verified && row.classification === "Confirmed Brilliant",
      );
      setRecords(verified);
      setSelected(verified[0] ?? null);
    });
  }, []);

  const tagOptions = useMemo(() => [...new Set(records.flatMap(patternTags))].sort(), [records]);
  const filtered = records.filter((record) => {
    const tags = patternTags(record);
    const matchesTag = filter === "all" || tags.includes(filter);
    const text =
      `${record.actualMove} ${record.gameMeta?.white ?? ""} ${record.gameMeta?.black ?? ""} ${tags.join(" ")}`.toLowerCase();
    return matchesTag && text.includes(query.toLowerCase());
  });
  const similar = selected ? findSimilarPatterns(selected, records, 8) : [];

  const remove = async (record: HunterFinding) => {
    await deleteVerifiedDiscovery(record.id);
    const next = records.filter((item) => item.id !== record.id);
    setRecords(next);
    if (selected?.id === record.id) setSelected(next[0] ?? null);
  };

  if (!records.length)
    return (
      <section className="panel p-5">
        <h2 className="text-xl font-semibold">Brilliant Move DNA</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          No verified discoveries are stored yet. Only verified Hunter findings can enter DNA;
          candidates remain separate.
        </p>
      </section>
    );

  return (
    <section className="flex flex-col gap-4">
      <div className="flex flex-wrap items-end gap-3">
        <div>
          <h2 className="text-xl font-semibold">Brilliant Move DNA</h2>
          <p className="text-xs text-muted-foreground">
            Normalized structure and motif signals help find patterns; similarity does not prove the
            same combination.
          </p>
        </div>
        <button
          onClick={() =>
            download(
              "brilliant-move-dna.json",
              JSON.stringify(records, null, 2),
              "application/json",
            )
          }
          className="ml-auto rounded border px-3 py-1.5 text-xs"
        >
          Export records
        </button>
      </div>
      <div className="grid gap-3 lg:grid-cols-[minmax(250px,0.8fr)_minmax(0,1.2fr)]">
        <aside className="panel flex max-h-[75vh] flex-col gap-2 overflow-auto p-3">
          <div className="flex gap-2">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search move, player, motif…"
              className="min-w-0 flex-1 rounded border bg-background px-2 py-1.5 text-xs"
            />
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="max-w-40 rounded border bg-background px-2 py-1.5 text-xs"
            >
              <option value="all">All tags</option>
              {tagOptions.map((tag) => (
                <option value={tag} key={tag}>
                  {tag}
                </option>
              ))}
            </select>
          </div>
          {filtered.map((record) => (
            <button
              key={record.id}
              onClick={() => setSelected(record)}
              className={`rounded p-2 text-left hover:bg-accent ${selected?.id === record.id ? "bg-accent" : ""}`}
            >
              <div className="flex items-center gap-2">
                <span className="font-mono">
                  {record.moveNumber}
                  {record.color === "w" ? "." : "…"} {record.actualMove}
                </span>
                <span className="ml-auto text-[10px] text-cls-brilliant">verified</span>
              </div>
              <div className="mt-1 text-[10px] text-muted-foreground">
                {record.gameMeta?.white ?? "Unknown"} – {record.gameMeta?.black ?? "Unknown"}
              </div>
              <div className="mt-1 flex flex-wrap gap-1">
                {patternTags(record).map((tag) => (
                  <span
                    className="rounded bg-panel-raised px-1.5 py-0.5 text-[9px] text-muted-foreground"
                    key={tag}
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </button>
          ))}
        </aside>
        {selected && (
          <article className="panel flex flex-col gap-3 p-4">
            <div className="flex flex-wrap items-start gap-2">
              <div>
                <h3 className="text-lg font-semibold text-cls-brilliant">
                  {selected.actualMove}!!
                </h3>
                <p className="text-xs text-muted-foreground">
                  {selected.gameMeta?.white ?? "Unknown"} – {selected.gameMeta?.black ?? "Unknown"}{" "}
                  · move {selected.moveNumber}
                </p>
              </div>
              <div className="ml-auto flex gap-2">
                <button
                  onClick={() =>
                    selected.sourcePgn &&
                    download("original-game.pgn", selected.sourcePgn, "application/x-chess-pgn")
                  }
                  disabled={!selected.sourcePgn}
                  className="rounded border px-3 py-1.5 text-xs disabled:opacity-40"
                >
                  Open / export source PGN
                </button>
                <button
                  onClick={() => void remove(selected)}
                  className="rounded border border-destructive/40 px-3 py-1.5 text-xs text-destructive"
                >
                  Remove DNA record
                </button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
              <Datum label="FEN" value={selected.fenBefore} mono />
              <Datum label="Engine depth" value={selected.engineDepth} />
              <Datum
                label="Best response"
                value={selected.bestOpponentResponse ?? "Unavailable"}
                mono
              />
              <Datum
                label="Material investment"
                value={selected.materialSacrifice ?? "None identified"}
              />
            </div>
            <p className="text-xs leading-relaxed">{selected.explanation}</p>
            <section className="rounded border p-3">
              <h4 className="text-sm font-semibold">Similar structural patterns</h4>
              <p className="mt-1 text-[10px] text-muted-foreground">
                Feature overlap is a browsing aid, not a probability and not a claim that two
                positions share the exact tactical combination.
              </p>
              {similar.length ? (
                <div className="mt-2 flex flex-col gap-2">
                  {similar.map((match) => (
                    <div
                      key={match.finding.id}
                      className="flex flex-wrap items-center gap-2 rounded bg-panel-raised p-2 text-xs"
                    >
                      <span className="font-mono">
                        {match.finding.actualMove} · {match.finding.gameMeta?.white ?? "Unknown"}
                      </span>
                      <span className="ml-auto">{match.overlap}% shared structural features</span>
                      <span className="w-full text-[10px] text-muted-foreground">
                        Shared tags: {match.sharedTags.join(", ") || "none"}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="mt-2 text-xs text-muted-foreground">
                  No other verified pattern is available to compare.
                </p>
              )}
            </section>
            <div className="rounded border p-3">
              <h4 className="text-sm font-semibold">Verified variation</h4>
              <p className="mt-1 font-mono text-xs">
                {selected.mainVariation.join(" ") || "No continuation stored"}
              </p>
            </div>
          </article>
        )}
      </div>
    </section>
  );
}

function Datum({ label, value, mono }: { label: string; value: string | number; mono?: boolean }) {
  return (
    <div className="min-w-0 rounded bg-panel-raised p-2">
      <div className="text-[10px] text-muted-foreground">{label}</div>
      <div className={`mt-1 break-all text-xs ${mono ? "font-mono" : ""}`}>{value}</div>
    </div>
  );
}
