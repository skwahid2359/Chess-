import { useEffect, useRef, useState } from "react";
import { Chess } from "chess.js";
import { UciEngine } from "@/lib/chess/engine";
import { scanPosition } from "@/lib/arena/hunter";
import type { HunterFinding } from "@/lib/arena/types";

type BenchmarkCase = {
  id: string;
  name: string;
  source: string;
  fen: string;
  targetUci?: string;
  expectedBrilliant: boolean;
  annotation: string;
};
type CaseResult = {
  caseId: string;
  coverage: boolean;
  verified: boolean;
  targetFound: boolean;
  predictedBrilliant: boolean;
  actual?: HunterFinding;
};
type BenchmarkRun = {
  id: string;
  createdAt: string;
  depth: number;
  engine: string;
  cases: number;
  results: CaseResult[];
  metrics: {
    precision: number | null;
    recall: number | null;
    falsePositiveRate: number | null;
    falseNegativeRate: number | null;
    candidateCoverage: number;
    verificationCompletionRate: number;
  };
};
const HISTORY_KEY = "chess-arena-benchmark-history-v1";

function parseCases(text: string): BenchmarkCase[] {
  const value = JSON.parse(text) as unknown;
  if (!Array.isArray(value) || !value.length || value.length > 200)
    throw new Error("Dataset must be a JSON array containing 1–200 reference positions.");
  return value.map((raw, index) => {
    if (!raw || typeof raw !== "object") throw new Error(`Position ${index + 1} is not an object.`);
    const item = raw as Partial<BenchmarkCase>;
    if (
      typeof item.name !== "string" ||
      typeof item.source !== "string" ||
      typeof item.fen !== "string" ||
      typeof item.expectedBrilliant !== "boolean" ||
      typeof item.annotation !== "string"
    )
      throw new Error(
        `Position ${index + 1} needs name, source, FEN, expectedBrilliant and annotation.`,
      );
    new Chess(item.fen);
    if (item.expectedBrilliant && !item.targetUci)
      throw new Error(`Positive position ${index + 1} needs a targetUci reference move.`);
    if (item.targetUci && !/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(item.targetUci))
      throw new Error(`Position ${index + 1} has an invalid targetUci.`);
    return {
      id: typeof item.id === "string" ? item.id : `case-${index + 1}`,
      name: item.name,
      source: item.source,
      fen: item.fen,
      targetUci: item.targetUci,
      expectedBrilliant: item.expectedBrilliant,
      annotation: item.annotation,
    };
  });
}

function loadHistory(): BenchmarkRun[] {
  try {
    const v = JSON.parse(localStorage.getItem(HISTORY_KEY) ?? "[]");
    return Array.isArray(v) ? v : [];
  } catch {
    return [];
  }
}

export function BenchmarkDashboard() {
  const [text, setText] = useState("");
  const [cases, setCases] = useState<BenchmarkCase[]>([]);
  const [run, setRun] = useState<BenchmarkRun | null>(null);
  const [history, setHistory] = useState<BenchmarkRun[]>([]);
  const [depth, setDepth] = useState(20);
  const [progress, setProgress] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState("Idle");
  const cancelled = useRef(false);
  const engineRef = useRef<UciEngine | null>(null);
  useEffect(() => setHistory(loadHistory()), []);

  const importDataset = () => {
    try {
      const parsed = parseCases(text);
      setCases(parsed);
      setError(null);
      try {
        localStorage.setItem("chess-arena-benchmark-dataset-v1", JSON.stringify(parsed));
      } catch {
        /* imported cases remain available in memory */
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Invalid benchmark dataset.");
    }
  };

  useEffect(() => {
    try {
      const stored = localStorage.getItem("chess-arena-benchmark-dataset-v1");
      if (stored) {
        const parsed = parseCases(stored);
        setCases(parsed);
        setText(stored);
      }
    } catch {
      /* invalid or unavailable saved dataset */
    }
  }, []);

  const runBenchmark = async () => {
    if (!cases.length || busy) return;
    cancelled.current = false;
    setBusy(true);
    setProgress(0);
    setError(null);
    const engine = new UciEngine();
    engineRef.current = engine;
    const off = engine.onStatus((s) =>
      setStatus(
        s === "ready" ? "Stockfish ready" : s === "failed" ? "Engine failed" : "Stockfish starting",
      ),
    );
    const results: CaseResult[] = [];
    try {
      for (let i = 0; i < cases.length; i++) {
        if (cancelled.current) break;
        const test = cases[i];
        const findings = await scanPosition(test.fen, engine, depth, 5, () => cancelled.current);
        if (cancelled.current) break;
        const target = test.targetUci
          ? findings.find((item) => item.actualMoveUci === test.targetUci)
          : undefined;
        const predictedBrilliant = test.expectedBrilliant
          ? !!target?.verified && target.classification === "Confirmed Brilliant"
          : findings.some((item) => item.verified && item.classification === "Confirmed Brilliant");
        const bestDepth = findings.reduce((max, item) => Math.max(max, item.engineDepth), 0);
        results.push({
          caseId: test.id,
          coverage: findings.length > 0,
          verified: bestDepth >= 20,
          targetFound: !!target,
          predictedBrilliant,
          actual: target,
        });
        setProgress(i + 1);
      }
      if (!results.length || cancelled.current) return;
      const positives = results.filter(
        (item) => cases.find((c) => c.id === item.caseId)?.expectedBrilliant,
      );
      const negatives = results.filter(
        (item) => !cases.find((c) => c.id === item.caseId)?.expectedBrilliant,
      );
      const tp = positives.filter((item) => item.predictedBrilliant).length;
      const fp = negatives.filter((item) => item.predictedBrilliant).length;
      const fn = positives.length - tp;
      const tn = negatives.length - fp;
      const pct = (a: number, b: number) => (b ? Math.round((a / b) * 1000) / 10 : null);
      const next: BenchmarkRun = {
        id: `${Date.now()}`,
        createdAt: new Date().toISOString(),
        depth,
        engine: "Stockfish 19 Lite single-thread (bundled WASM)",
        cases: results.length,
        results,
        metrics: {
          precision: pct(tp, tp + fp),
          recall: pct(tp, tp + fn),
          falsePositiveRate: pct(fp, fp + tn),
          falseNegativeRate: pct(fn, fn + tp),
          candidateCoverage:
            pct(results.filter((item) => item.coverage).length, results.length) ?? 0,
          verificationCompletionRate:
            pct(results.filter((item) => item.verified).length, results.length) ?? 0,
        },
      };
      setRun(next);
      const updated = [next, ...history].slice(0, 40);
      setHistory(updated);
      try {
        localStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
      } catch {
        /* current run remains in memory */
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Benchmark could not complete.");
    } finally {
      off();
      engine.destroy();
      engineRef.current = null;
      setBusy(false);
      if (engine.status !== "failed") setStatus("Benchmark complete");
    }
  };

  const download = (name: string, value: string) => {
    const url = URL.createObjectURL(new Blob([value], { type: "application/json" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <section className="flex flex-col gap-4">
      <header className="flex flex-wrap items-center gap-3">
        <div>
          <h2 className="text-xl font-semibold">Discovery Benchmark</h2>
          <p className="text-xs text-muted-foreground">
            No benchmark score is shown until an attributed reference dataset has actually been run.
          </p>
        </div>
        <button
          onClick={() => download("hunter-benchmark.json", JSON.stringify(history, null, 2))}
          disabled={!history.length}
          className="ml-auto rounded border px-3 py-1.5 text-xs disabled:opacity-40"
        >
          Export run history
        </button>
      </header>
      <div className="panel flex flex-col gap-3 p-3">
        <div className="flex flex-wrap items-center gap-3">
          <label className="text-xs">
            Search depth{" "}
            <select
              value={depth}
              onChange={(e) => setDepth(Number(e.target.value))}
              disabled={busy}
              className="ml-2 rounded border bg-background px-2 py-1"
            >
              <option value={16}>16 · exploratory</option>
              <option value={20}>20 · verification gate</option>
              <option value={22}>22 · deep</option>
            </select>
          </label>
          <span className="text-[10px] text-muted-foreground">
            Engine: Stockfish 19 Lite single-thread WASM · version/config captured in each run.
          </span>
        </div>
        <label htmlFor="bench-json" className="text-sm font-semibold">
          Attributed reference-position dataset (JSON)
        </label>
        <textarea
          id="bench-json"
          value={text}
          onChange={(e) => setText(e.target.value)}
          disabled={busy}
          placeholder={
            '[{"name":"Position name","source":"Game/source citation","fen":"...","targetUci":"e2e4","expectedBrilliant":true,"annotation":"Expert note; not an engine result"}]'
          }
          className="h-40 resize-y rounded border bg-background p-2 font-mono text-[11px]"
        />
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={importDataset}
            disabled={busy || !text.trim()}
            className="rounded border px-3 py-1.5 text-xs disabled:opacity-40"
          >
            Validate / load dataset
          </button>
          <span className="text-xs text-muted-foreground">
            {cases.length} attributed positions loaded
          </span>
          {busy ? (
            <button
              onClick={() => {
                cancelled.current = true;
                engineRef.current?.cancel();
              }}
              className="ml-auto rounded border border-destructive/40 px-3 py-1.5 text-xs text-destructive"
            >
              Cancel · {progress}/{cases.length}
            </button>
          ) : (
            <button
              onClick={() => void runBenchmark()}
              disabled={!cases.length}
              className="ml-auto rounded bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground disabled:opacity-40"
            >
              Run benchmark
            </button>
          )}
        </div>
        <p className="text-[10px] leading-relaxed text-muted-foreground">
          Each item must contain a source and human-curated expectedBrilliant label. Positive cases
          must include targetUci. Expert annotations and engine verification are reported
          separately. Difficult/excluded positions must remain in the dataset; incomplete runs do
          not create a benchmark report.
        </p>
      </div>
      {error && (
        <p
          role="alert"
          className="rounded border border-destructive/40 bg-destructive/10 p-2 text-xs text-destructive"
        >
          {error}
        </p>
      )}
      <p className="text-xs text-muted-foreground">Engine status: {status}</p>
      {run && (
        <div className="panel flex flex-col gap-3 p-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="font-semibold">
              Latest actual run · {new Date(run.createdAt).toLocaleString()}
            </h3>
            <span className="text-xs text-muted-foreground">
              {run.cases} positions · depth {run.depth}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {metric("Precision", run.metrics.precision)}
            {metric("Recall", run.metrics.recall)}
            {metric("False positive rate", run.metrics.falsePositiveRate)}
            {metric("False negative rate", run.metrics.falseNegativeRate)}
            {metric("Candidate coverage", run.metrics.candidateCoverage)}
            {metric("Verification completion", run.metrics.verificationCompletionRate)}
          </div>
          <div className="max-h-60 overflow-auto">
            {cases.map((test) => {
              const row = run.results.find((item) => item.caseId === test.id);
              return (
                <div
                  key={test.id}
                  className="grid grid-cols-[1fr_auto_auto] gap-2 border-t py-2 text-xs"
                >
                  <span>
                    {test.name}
                    <span className="ml-2 text-[10px] text-muted-foreground">{test.source}</span>
                  </span>
                  <span>{row?.coverage ? "covered" : "not covered"}</span>
                  <span
                    className={
                      row?.predictedBrilliant === test.expectedBrilliant
                        ? "text-cls-brilliant"
                        : "text-cls-blunder"
                    }
                  >
                    {row?.predictedBrilliant ? "Hunter: Brilliant" : "Hunter: not confirmed"}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
      {history.length > 1 && (
        <div className="panel p-3">
          <h3 className="font-semibold">Historical benchmark runs</h3>
          <div className="mt-2 flex flex-col gap-2">
            {history.slice(1, 8).map((item) => (
              <button
                key={item.id}
                onClick={() => setRun(item)}
                className="flex justify-between gap-2 border-t py-2 text-left text-xs"
              >
                <span>
                  {new Date(item.createdAt).toLocaleString()} · depth {item.depth}
                </span>
                <span>
                  {item.cases} positions · precision {formatMetric(item.metrics.precision)}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}

function formatMetric(value: number | null) {
  return value === null ? "N/A" : `${value.toFixed(1)}%`;
}
function metric(label: string, value: number | null) {
  return (
    <div className="rounded bg-panel-raised p-2">
      <div className="text-lg font-semibold">{formatMetric(value)}</div>
      <div className="text-[10px] text-muted-foreground">{label}</div>
    </div>
  );
}
