import { Chess } from "chess.js";
import { useEffect, useMemo, useState } from "react";
import { Board } from "@/components/chess/Board";
import { listVerifiedDiscoveries } from "@/lib/arena/storage";
import type { HunterFinding } from "@/lib/arena/types";

type Props = { mode: "human" | "training" };
type Stats = { solved: number; attempts: number; hints: number; elapsedSeconds: number };
const EMPTY_STATS: Stats = { solved: 0, attempts: 0, hints: 0, elapsedSeconds: 0 };

function loadStats(): Stats {
  try {
    const value = JSON.parse(localStorage.getItem("chess-arena-training-stats-v1") ?? "{}");
    return {
      solved: Number(value.solved) || 0,
      attempts: Number(value.attempts) || 0,
      hints: Number(value.hints) || 0,
      elapsedSeconds: Number(value.elapsedSeconds) || 0,
    };
  } catch {
    return EMPTY_STATS;
  }
}

export function PuzzleWorkspace({ mode }: Props) {
  const [discoveries, setDiscoveries] = useState<HunterFinding[]>([]);
  const [finding, setFinding] = useState<HunterFinding | null>(null);
  const [fen, setFen] = useState("");
  const [message, setMessage] = useState("Choose a verified discovery to begin.");
  const [revealed, setRevealed] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [hint, setHint] = useState(false);
  const [timerOn, setTimerOn] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [stats, setStats] = useState<Stats>(EMPTY_STATS);

  useEffect(() => {
    void listVerifiedDiscoveries().then((rows) => {
      const verified = rows.filter(
        (row) => row.verified && row.classification === "Confirmed Brilliant",
      );
      setDiscoveries(verified);
      if (verified.length) {
        const initial = verified[Math.floor(Math.random() * verified.length)];
        setFinding(initial);
        setFen(initial.fenBefore);
        setMessage("Find the move that survives the strongest searched defense.");
      }
    });
    setStats(loadStats());
  }, []);

  useEffect(() => {
    if (!timerOn || completed || revealed || !finding) return;
    const timer = window.setInterval(() => setElapsed((seconds) => seconds + 1), 1000);
    return () => window.clearInterval(timer);
  }, [timerOn, completed, revealed, finding]);

  const selectPuzzle = (item?: HunterFinding) => {
    const next = item ?? discoveries[Math.floor(Math.random() * discoveries.length)];
    if (!next) return;
    setFinding(next);
    setFen(next.fenBefore);
    setMessage("Find the move that survives the strongest searched defense.");
    setRevealed(false);
    setCompleted(false);
    setAttempts(0);
    setHint(false);
    setElapsed(0);
  };

  const solution = finding?.actualMoveUci || finding?.bestMoveUci;
  const accepted = useMemo(
    () => new Set([finding?.actualMoveUci, finding?.bestMoveUci].filter((x): x is string => !!x)),
    [finding],
  );

  const playMove = (from: string, to: string, promotion?: string) => {
    if (!finding || completed || revealed) return false;
    const chess = new Chess(fen);
    try {
      const move = chess.move({ from, to, promotion: promotion ?? "q" });
      const uci = move.from + move.to + (move.promotion ?? "");
      setAttempts((n) => n + 1);
      if (accepted.has(uci)) {
        setFen(chess.fen());
        setCompleted(true);
        setMessage(`Correct: ${move.san} matches the verified Hunter move.`);
        const current = loadStats();
        const next = {
          ...current,
          solved: current.solved + 1,
          attempts: current.attempts + attempts + 1,
          hints: current.hints + Number(hint),
          elapsedSeconds: current.elapsedSeconds + elapsed,
        };
        setStats(next);
        try {
          localStorage.setItem("chess-arena-training-stats-v1", JSON.stringify(next));
        } catch {
          /* in-memory stats remain */
        }
      } else
        setMessage(
          `${move.san} is legal but does not match this verified solution. You can try again or reveal the line.`,
        );
      return true;
    } catch {
      return false;
    }
  };

  const requestHint = () => {
    setHint(true);
    setMessage(
      solution
        ? `Hint: the move starts with the piece on ${solution.slice(0, 2)}.`
        : "No verified solution is available for this record.",
    );
  };

  const reveal = () => {
    setRevealed(true);
    setMessage(
      solution
        ? `Verified solution: ${finding?.actualMove} · ${finding?.bestOpponentResponse ? `best searched reply ${finding.bestOpponentResponse}` : "reply not recorded"}.`
        : "No verified line is stored for this discovery.",
    );
  };

  const title = mode === "human" ? "Human vs Hunter" : "Brilliant Training";
  if (!discoveries.length)
    return (
      <section className="panel p-5">
        <h2 className="text-xl font-semibold">{title}</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          No verified discoveries are stored yet. Run a deep Brilliant Hunter scan first;
          provisional candidates never become puzzles.
        </p>
      </section>
    );

  return (
    <section className="flex flex-col gap-4">
      <header className="flex flex-wrap items-center gap-3">
        <div>
          <h2 className="text-xl font-semibold">{title}</h2>
          <p className="text-xs text-muted-foreground">
            Verified discoveries only · attempts are credited only for the stored engine-verified
            move.
          </p>
        </div>
        <label className="ml-auto flex items-center gap-2 text-xs">
          <input type="checkbox" checked={timerOn} onChange={(e) => setTimerOn(e.target.checked)} />{" "}
          Optional timer
        </label>
        <button
          onClick={() => selectPuzzle()}
          className="rounded bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground"
        >
          Random verified puzzle
        </button>
      </header>
      <div className="grid gap-4 lg:grid-cols-[minmax(0,580px)_minmax(280px,1fr)]">
        <div className="flex gap-2">
          <div className="flex-1">
            <Board fen={fen || finding?.fenBefore || ""} orientation="w" onMove={playMove} />
          </div>
        </div>
        <aside className="panel flex flex-col gap-3 p-4">
          <div className="flex items-center gap-2">
            <span
              className="cls-badge h-6 w-6 text-xs"
              style={{ background: "var(--cls-brilliant)" }}
            >
              !!
            </span>
            <span className="font-semibold text-cls-brilliant">Verified Brilliant puzzle</span>
          </div>
          <p className="text-sm leading-relaxed">{message}</p>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="rounded bg-panel-raised p-2">
              <div className="text-muted-foreground">Tactical complexity</div>
              <div>{finding?.tacticalComplexity}</div>
            </div>
            <div className="rounded bg-panel-raised p-2">
              <div className="text-muted-foreground">Discovery difficulty</div>
              <div>{finding?.discoveryDifficulty}</div>
            </div>
            <div className="rounded bg-panel-raised p-2">
              <div className="text-muted-foreground">Search confidence</div>
              <div>{finding?.confidence}</div>
            </div>
            <div className="rounded bg-panel-raised p-2">
              <div className="text-muted-foreground">Elapsed</div>
              <div>
                {elapsed}s {timerOn ? "· timed" : "· untimed"}
              </div>
            </div>
          </div>
          {hint && solution && (
            <p className="rounded border p-2 font-mono text-xs">
              Hint square: {solution.slice(0, 2)}
            </p>
          )}
          {(completed || revealed) && (
            <div className="rounded border border-cls-brilliant/40 bg-cls-brilliant/10 p-2 text-xs">
              <div className="font-semibold">Solution line</div>
              <div className="mt-1 font-mono">
                {finding?.actualMove}{" "}
                {finding?.bestOpponentResponse ? `${finding.bestOpponentResponse} …` : ""}
              </div>
              <div className="mt-1 text-muted-foreground">{finding?.explanation}</div>
            </div>
          )}
          <div className="mt-auto flex flex-wrap gap-2">
            <button
              onClick={requestHint}
              disabled={completed || revealed}
              className="rounded border px-3 py-1.5 text-xs disabled:opacity-40"
            >
              Hint
            </button>
            <button
              onClick={reveal}
              disabled={completed || revealed}
              className="rounded border px-3 py-1.5 text-xs disabled:opacity-40"
            >
              Reveal solution
            </button>
            <button
              onClick={() => selectPuzzle()}
              className="ml-auto rounded bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground"
            >
              Next puzzle
            </button>
          </div>
          <div className="border-t pt-2 text-[10px] text-muted-foreground">
            Training history · solved {stats.solved} · attempts {stats.attempts} · hints{" "}
            {stats.hints} · time {stats.elapsedSeconds}s
          </div>
        </aside>
      </div>
    </section>
  );
}
