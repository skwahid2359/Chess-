import { Chess } from "chess.js";
import { useEffect, useMemo, useRef, useState } from "react";
import { Board } from "@/components/chess/Board";
import { UciEngine } from "@/lib/chess/engine";
import { formatScore, numberLine } from "@/lib/chess/eval";
import { parsePgn, PgnError, SAMPLE_PGN } from "@/lib/chess/pgn";
import { listBotGames, saveVerifiedDiscovery } from "@/lib/arena/storage";
import { scanGame, scanPosition } from "@/lib/arena/hunter";
import type { BotGameRecord, HunterFinding, HunterScanProgress } from "@/lib/arena/types";

type Props = { mode: "game" | "position"; onBack?: () => void };
type ScanPreset = "fast" | "balanced" | "deep";
const PRESETS: Record<
  ScanPreset,
  { depth: number; maxMoves: number; candidates: number; label: string }
> = {
  fast: { depth: 12, maxMoves: 16, candidates: 2, label: "Fast scan" },
  balanced: { depth: 16, maxMoves: 40, candidates: 3, label: "Balanced scan" },
  deep: { depth: 20, maxMoves: 80, candidates: 5, label: "Deep scan" },
};
const CLASS_COLORS: Record<HunterFinding["classification"], string> = {
  "Confirmed Brilliant": "text-cls-brilliant",
  "Strong Candidate": "text-cls-great",
  Interesting: "text-cls-best",
  Speculative: "text-cls-inaccuracy",
  Refuted: "text-cls-blunder",
  "Needs Deeper Analysis": "text-muted-foreground",
};

export function HunterWorkspace({ mode, onBack }: Props) {
  const [pgn, setPgn] = useState("");
  const [fen, setFen] = useState("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
  const [error, setError] = useState<string | null>(null);
  const [preset, setPreset] = useState<ScanPreset>("balanced");
  const [running, setRunning] = useState(false);
  const [paused, setPaused] = useState(false);
  const [cancelled, setCancelled] = useState(false);
  const [engineStatus, setEngineStatus] = useState("Idle");
  const [progress, setProgress] = useState<HunterScanProgress | null>(null);
  const [findings, setFindings] = useState<HunterFinding[]>([]);
  const [selected, setSelected] = useState<HunterFinding | null>(null);
  const [recentGames, setRecentGames] = useState<BotGameRecord[]>([]);
  const cancelledRef = useRef(false);
  const pausedRef = useRef(false);
  const resumeWaiters = useRef<(() => void)[]>([]);
  const engineRef = useRef<UciEngine | null>(null);
  const config = PRESETS[preset];

  useEffect(() => {
    void listBotGames().then(setRecentGames);
  }, []);
  useEffect(
    () => () => {
      cancelledRef.current = true;
      engineRef.current?.destroy();
      resumeWaiters.current.splice(0).forEach((resolve) => resolve());
    },
    [],
  );

  const parsedGame = useMemo(() => {
    if (!pgn.trim()) return null;
    try {
      return parsePgn(pgn);
    } catch {
      return null;
    }
  }, [pgn]);
  const pausedWait = () =>
    new Promise<void>((resolve) => {
      if (!pausedRef.current) resolve();
      else resumeWaiters.current.push(resolve);
    });

  const stopEngine = () => {
    cancelledRef.current = true;
    setCancelled(true);
    setPaused(false);
    pausedRef.current = false;
    engineRef.current?.cancel();
    resumeWaiters.current.splice(0).forEach((resolve) => resolve());
  };
  const resume = () => {
    pausedRef.current = false;
    setPaused(false);
    resumeWaiters.current.splice(0).forEach((resolve) => resolve());
  };
  const pause = () => {
    pausedRef.current = true;
    setPaused(true);
  };

  const begin = async (kind: "game" | "position") => {
    if (running) return;
    setError(null);
    setFindings([]);
    setSelected(null);
    setProgress(null);
    setCancelled(false);
    cancelledRef.current = false;
    pausedRef.current = false;
    setPaused(false);
    const engine = new UciEngine();
    engineRef.current = engine;
    const off = engine.onStatus((status) =>
      setEngineStatus(
        status === "ready"
          ? "Stockfish ready"
          : status === "failed"
            ? "Engine failed to start"
            : "Stockfish starting",
      ),
    );
    setRunning(true);
    const startTime = performance.now();
    try {
      const result =
        kind === "game"
          ? (() => {
              const game = parsePgn(pgn);
              if (!game.moves.length) throw new PgnError("No moves were found in this PGN.");
              const maxMoves = Math.min(config.maxMoves, game.moves.length);
              setProgress({ done: 0, total: maxMoves, candidates: 0, elapsedMs: 0 });
              return scanGame(
                game,
                engine,
                { depth: config.depth, maxMoves, candidateCount: config.candidates },
                {
                  isCancelled: () => cancelledRef.current,
                  waitWhilePaused: pausedWait,
                  onProgress: setProgress,
                },
              );
            })()
          : (() => {
              new Chess(fen);
              setProgress({ done: 0, total: config.candidates, candidates: 0, elapsedMs: 0 });
              return scanPosition(
                fen,
                engine,
                config.depth,
                config.candidates,
                () => cancelledRef.current,
              ).then((items) => {
                setProgress({
                  done: config.candidates,
                  total: config.candidates,
                  candidates: items.length,
                  elapsedMs: performance.now() - startTime,
                });
                return items;
              });
            })();
      const rows = await result;
      if (!cancelledRef.current) {
        for (const row of rows) if (row.verified) await saveVerifiedDiscovery(row);
        setFindings(rows);
        if (rows[0]) setSelected(rows[0]);
      } else setFindings(rows);
    } catch (e) {
      setError(
        e instanceof PgnError || e instanceof Error
          ? e.message
          : "Hunter scan could not be completed.",
      );
    } finally {
      off();
      engine.destroy();
      engineRef.current = null;
      setRunning(false);
      setPaused(false);
      pausedRef.current = false;
      if (engine.status === "failed")
        setEngineStatus("Engine failed; verify the worker/WASM asset path in this browser.");
      else setEngineStatus("Scan complete");
    }
  };

  const onFile = async (file?: File) => {
    if (!file) return;
    try {
      const text = await file.text();
      setPgn(text);
      setError(null);
    } catch {
      setError("Could not read the selected PGN file.");
    }
  };

  const metrics = useMemo(
    () => ({
      confirmed: findings.filter((item) => item.classification === "Confirmed Brilliant").length,
      strong: findings.filter((item) => item.classification === "Strong Candidate").length,
      refuted: findings.filter((item) => item.classification === "Refuted").length,
      interesting: findings.filter((item) => item.classification === "Interesting").length,
      unverified: findings.filter((item) => !item.verified).length,
    }),
    [findings],
  );

  return (
    <section className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center gap-2">
        {onBack && (
          <button onClick={onBack} className="rounded border px-3 py-1.5 text-xs hover:bg-accent">
            ← Bot Arena
          </button>
        )}
        <div>
          <h2 className="text-xl font-semibold">
            {mode === "game" ? "Brilliant Hunter" : "Discovery Lab"}
          </h2>
          <p className="text-xs text-muted-foreground">
            Real Stockfish search · provisional results stay provisional · verified discoveries only
            are saved.
          </p>
        </div>
      </div>

      <div className="panel flex flex-wrap items-end gap-3 p-3">
        <label className="flex flex-col gap-1 text-[11px] text-muted-foreground">
          Scan profile
          <select
            value={preset}
            onChange={(e) => setPreset(e.target.value as ScanPreset)}
            disabled={running}
            className="rounded border bg-background px-2 py-1.5 text-foreground"
          >
            {Object.entries(PRESETS).map(([key, item]) => (
              <option key={key} value={key}>
                {item.label} · depth {item.depth} · up to {item.maxMoves} positions
              </option>
            ))}
          </select>
        </label>
        <div className="text-[11px] text-muted-foreground">
          Bounded workload: up to{" "}
          {mode === "game"
            ? `${Math.min(config.maxMoves, parsedGame?.moves.length ?? config.maxMoves)} positions × 2 searches`
            : `${config.candidates} candidate moves × 2 searches`}
          . Results depend on device speed and search horizon.
        </div>
        {running ? (
          <div className="ml-auto flex gap-2">
            {paused ? (
              <button
                onClick={resume}
                className="rounded bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground"
              >
                Resume
              </button>
            ) : (
              <button onClick={pause} className="rounded border px-3 py-1.5 text-xs">
                Pause
              </button>
            )}
            <button
              onClick={stopEngine}
              className="rounded border border-destructive/50 px-3 py-1.5 text-xs text-destructive"
            >
              Cancel
            </button>
          </div>
        ) : (
          <button
            onClick={() => void begin(mode)}
            disabled={mode === "game" ? !pgn.trim() : !fen.trim()}
            className="ml-auto rounded bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground disabled:opacity-40"
          >
            {mode === "game" ? "Scan PGN" : "Scan Position"}
          </button>
        )}
      </div>

      {mode === "game" ? (
        <div className="panel flex flex-col gap-2 p-3">
          <div className="flex items-center justify-between">
            <label htmlFor="hunter-pgn" className="text-sm font-semibold">
              Game PGN
            </label>
            <span className="text-xs text-muted-foreground">
              {parsedGame
                ? `${parsedGame.moves.length} plies · ${parsedGame.meta.white} – ${parsedGame.meta.black}`
                : "Paste, upload, or select a recent bot game"}
            </span>
          </div>
          <textarea
            id="hunter-pgn"
            value={pgn}
            onChange={(e) => setPgn(e.target.value)}
            disabled={running}
            placeholder='[White "Player"] [Black "Opponent"] 1. e4 e5 …'
            className="h-36 resize-y rounded border bg-background p-2 font-mono text-xs"
          />
          <div className="flex flex-wrap gap-2">
            <label className="cursor-pointer rounded border px-3 py-1.5 text-xs hover:bg-accent">
              Upload PGN
              <input
                type="file"
                accept=".pgn,text/plain"
                className="hidden"
                onChange={(e) => void onFile(e.target.files?.[0])}
              />
            </label>
            <button
              onClick={() => {
                setPgn(SAMPLE_PGN);
                setError(null);
              }}
              className="rounded border px-3 py-1.5 text-xs hover:bg-accent"
            >
              Load Morphy sample
            </button>
            {recentGames.length > 0 && (
              <select
                aria-label="Load recent bot game"
                className="rounded border bg-background px-2 py-1 text-xs"
                defaultValue=""
                onChange={(e) => {
                  const game = recentGames.find((item) => item.id === e.target.value);
                  if (game) setPgn(game.pgn);
                }}
              >
                <option value="">Recent bot games…</option>
                {recentGames.map((game) => (
                  <option value={game.id} key={game.id}>
                    {game.white} vs {game.black} · {new Date(game.createdAt).toLocaleDateString()}
                  </option>
                ))}
              </select>
            )}
          </div>
        </div>
      ) : (
        <div className="panel flex flex-col gap-2 p-3">
          <label htmlFor="hunter-fen" className="text-sm font-semibold">
            FEN position
          </label>
          <textarea
            id="hunter-fen"
            value={fen}
            onChange={(e) => setFen(e.target.value)}
            disabled={running}
            className="h-20 resize-y rounded border bg-background p-2 font-mono text-xs"
          />
          <p className="text-[11px] text-muted-foreground">
            Position setup is FEN-based in this first workspace slice. Invalid FEN is rejected
            before engine search.
          </p>
        </div>
      )}

      {error && (
        <p
          role="alert"
          className="rounded border border-destructive/40 bg-destructive/10 p-2 text-xs text-destructive"
        >
          {error}
        </p>
      )}
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
        <span>Engine: {engineStatus}</span>
        {progress && (
          <>
            <span>
              {progress.done}/{progress.total} positions
            </span>
            <span>{progress.candidates} candidate records</span>
            <span>{(progress.elapsedMs / 1000).toFixed(1)}s</span>
            {progress.currentMove && <span>Now: {progress.currentMove}</span>}
          </>
        )}
        {cancelled && <span>Cancelled; completed positions are retained in this report.</span>}
      </div>
      {running && (
        <div className="h-1.5 overflow-hidden rounded bg-muted">
          <div
            className="h-full bg-primary transition-[width]"
            style={{ width: `${progress?.total ? (progress.done / progress.total) * 100 : 0}%` }}
          />
        </div>
      )}

      {findings.length > 0 || (progress !== null && progress.done > 0 && !running) ? (
        <>
          <div className="panel grid grid-cols-2 gap-3 p-3 text-xs sm:grid-cols-6">
            <Metric
              label={mode === "game" ? "Moves scanned" : "Candidates searched"}
              value={progress?.done ?? findings.length}
            />
            <Metric label="Confirmed Brilliant" value={metrics.confirmed} />
            <Metric label="Strong candidates" value={metrics.strong} />
            <Metric label="Interesting" value={metrics.interesting} />
            <Metric label="Refuted sacrifices" value={metrics.refuted} />
            <Metric label="Unverified" value={metrics.unverified} />
            <div className="col-span-2 text-[10px] text-muted-foreground sm:col-span-6">
              Engine depth: {config.depth}. This scan's candidates are not a calibrated benchmark;
              report only completed engine searches.
            </div>
          </div>
          <div className="grid gap-3 xl:grid-cols-[minmax(280px,0.9fr)_minmax(0,1.1fr)]">
            <div className="panel max-h-[65vh] overflow-auto p-2">
              <h3 className="px-2 py-1 text-sm font-semibold">
                Candidate report · {findings.length}
              </h3>
              {!findings.length && (
                <p className="p-2 text-xs text-muted-foreground">
                  No moves met the current Hunter candidate criteria at this search depth. This is a
                  real zero-candidate result, not a failed run.
                </p>
              )}
              <div className="flex flex-col gap-1">
                {findings.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setSelected(item)}
                    className={`rounded p-2 text-left hover:bg-accent ${selected?.id === item.id ? "bg-accent" : ""}`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs">
                        {item.moveNumber}
                        {item.color === "w" ? "." : "…"} {item.actualMove}
                      </span>
                      <span
                        className={`ml-auto text-[10px] font-semibold ${CLASS_COLORS[item.classification]}`}
                      >
                        {item.classification}
                      </span>
                    </div>
                    <div className="mt-1 flex flex-wrap gap-x-3 text-[10px] text-muted-foreground">
                      <span>{item.verified ? "Verified" : "Provisional"}</span>
                      <span>depth {item.engineDepth}</span>
                      <span>loss {item.winChanceLoss.toFixed(1)}%</span>
                      <span>complexity {item.tacticalComplexity.toLowerCase()}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
            {selected && <FindingDetail finding={selected} />}
          </div>
        </>
      ) : null}
    </section>
  );
}

function Metric({ label, value }: { label: string; value: string | number }) {
  return (
    <div>
      <div className="text-lg font-semibold tabular-nums">{value}</div>
      <div className="text-[10px] text-muted-foreground">{label}</div>
    </div>
  );
}

function FindingDetail({ finding }: { finding: HunterFinding }) {
  return (
    <article className="panel flex flex-col gap-3 p-3">
      <div className="flex flex-wrap items-center gap-2">
        <h3 className={`font-semibold ${CLASS_COLORS[finding.classification]}`}>
          {finding.classification}
        </h3>
        <span className="ml-auto text-[10px] text-muted-foreground">
          {finding.confidence} confidence · depth {finding.engineDepth}
        </span>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <div className="mb-1 text-[11px] text-muted-foreground">
            Before · {finding.actualMove}
          </div>
          <Board fen={finding.fenBefore} orientation="w" onMove={() => false} />
        </div>
        <div>
          <div className="mb-1 text-[11px] text-muted-foreground">After played move</div>
          <Board fen={finding.fenAfter} orientation="w" onMove={() => false} />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2 rounded border bg-panel-raised p-2 text-xs sm:grid-cols-4">
        <Metric label="Engine eval before" value={formatScore(finding.before)} />
        <Metric label="Engine eval after" value={formatScore(finding.after)} />
        <Metric label="Tactical complexity" value={finding.tacticalComplexity} />
        <Metric label="Discovery difficulty · heuristic" value={finding.discoveryDifficulty} />
        <div className="col-span-2 text-[10px] text-muted-foreground sm:col-span-4">
          Objective strength loss: {finding.winChanceLoss.toFixed(1)} win-% points · material
          investment: {finding.materialSacrifice ?? "none identified"} · candidates:{" "}
          {finding.candidateCount}
        </div>
      </div>
      <p className="text-xs leading-relaxed">{finding.explanation}</p>
      <div className="grid gap-2 text-xs sm:grid-cols-2">
        <p>
          <span className="text-muted-foreground">Best candidate: </span>
          <span className="font-mono">{finding.bestMove ?? "Unavailable"}</span>
        </p>
        <p>
          <span className="text-muted-foreground">Best searched defense: </span>
          <span className="font-mono">{finding.bestOpponentResponse ?? "Unavailable"}</span>
        </p>
      </div>
      {finding.mainVariation.length > 0 && (
        <p className="rounded bg-panel-raised p-2 font-mono text-[11px] leading-relaxed">
          {numberLine(finding.fenBefore, finding.mainVariation)}
        </p>
      )}
      {finding.verified && (
        <p className="text-[10px] text-cls-brilliant">
          This record meets the current depth and multi-line verification gate and is eligible for
          verified discovery storage.
        </p>
      )}
    </article>
  );
}
