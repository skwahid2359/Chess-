import { Chess, DEFAULT_POSITION } from "chess.js";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Board } from "@/components/chess/Board";
import { EvalBar } from "@/components/chess/EvalBar";
import { UciEngine } from "@/lib/chess/engine";
import { formatScore, terminalScore } from "@/lib/chess/eval";
import type { Score } from "@/lib/chess/types";
import {
  BOT_PROFILES,
  PERSONALITIES,
  selectBotLine,
  type BotDifficulty,
  type BotPersonality,
} from "@/lib/arena/bots";
import { countCoveredLegalMoves, selectBrilliantSearchLine } from "@/lib/arena/brilliant-search";
import { saveBotGame } from "@/lib/arena/storage";
import type { BotGameRecord } from "@/lib/arena/types";

type TimeControl = { id: string; label: string; initialMs: number; incrementMs: number };
const TIME_CONTROLS: TimeControl[] = [
  { id: "unlimited", label: "Unlimited", initialMs: 0, incrementMs: 0 },
  { id: "3+2", label: "3 min + 2 sec", initialMs: 180_000, incrementMs: 2_000 },
  { id: "5+0", label: "5 min", initialMs: 300_000, incrementMs: 0 },
  { id: "10+0", label: "10 min", initialMs: 600_000, incrementMs: 0 },
];

type Ply = { uci: string; san: string; color: "w" | "b" };
const INITIAL_CLOCKS = { w: 300_000, b: 300_000 };

function clockText(ms: number, unlimited: boolean) {
  if (unlimited) return "∞";
  const total = Math.ceil(ms / 1000);
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, "0")}`;
}

function resultOf(chess: Chess, adjudication: string | null) {
  if (adjudication) return adjudication;
  if (chess.isCheckmate()) return chess.turn() === "w" ? "0-1" : "1-0";
  if (chess.isDraw() || chess.isStalemate()) return "1/2-1/2";
  return null;
}

function pgnFor(moves: Ply[], result: string, playerColor: "w" | "b", bot: string, date: Date) {
  const replay = new Chess();
  for (const item of moves)
    replay.move({ from: item.uci.slice(0, 2), to: item.uci.slice(2, 4), promotion: item.uci[4] });
  replay.header(
    "Event",
    "Chess Insights Bot Arena",
    "Date",
    date.toISOString().slice(0, 10).replaceAll("-", "."),
    "White",
    playerColor === "w" ? "You" : bot,
    "Black",
    playerColor === "b" ? "You" : bot,
    "Result",
    result,
  );
  return replay.pgn();
}

function downloadText(filename: string, text: string) {
  const url = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function BotGame() {
  const [difficulty, setDifficulty] = useState<BotDifficulty>("intermediate");
  const [personality, setPersonality] = useState<BotPersonality>("balanced");
  const [colorChoice, setColorChoice] = useState<"white" | "black" | "random">("white");
  const [playerColor, setPlayerColor] = useState<"w" | "b">("w");
  const [timeId, setTimeId] = useState("5+0");
  const timeControl = TIME_CONTROLS.find((item) => item.id === timeId) ?? TIME_CONTROLS[2];
  const [started, setStarted] = useState(false);
  const [fen, setFen] = useState(DEFAULT_POSITION);
  const [moves, setMoves] = useState<Ply[]>([]);
  const [clocks, setClocks] = useState(INITIAL_CLOCKS);
  const [adjudication, setAdjudication] = useState<string | null>(null);
  const [thinking, setThinking] = useState(false);
  const [engineStatus, setEngineStatus] = useState<"starting" | "ready" | "failed">("starting");
  const [score, setScore] = useState<Score | null>(null);
  const [brilliantProgress, setBrilliantProgress] = useState<{
    covered: number;
    total: number;
    complete: boolean;
    comparable: boolean;
    selectedTactical: boolean;
  } | null>(null);
  const [orientation, setOrientation] = useState<"w" | "b">("w");
  const engineRef = useRef<UciEngine | null>(null);
  const clockRef = useRef(clocks);
  const gameIdRef = useRef("");

  const chess = useMemo(() => new Chess(fen), [fen]);
  const turn = chess.turn();
  const ending = resultOf(chess, adjudication);
  const profile = BOT_PROFILES.find((item) => item.id === difficulty) ?? BOT_PROFILES[2];
  const botName = `${profile.label} Stockfish`;

  useEffect(() => {
    const engine = new UciEngine();
    engineRef.current = engine;
    const off = engine.onStatus(setEngineStatus);
    return () => {
      off();
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  useEffect(() => {
    clockRef.current = clocks;
  }, [clocks]);

  useEffect(() => {
    if (!started || ending || !timeControl.initialMs) return;
    const timer = window.setInterval(() => {
      const next = { ...clockRef.current, [turn]: Math.max(0, clockRef.current[turn] - 250) };
      clockRef.current = next;
      setClocks(next);
      if (next[turn] <= 0) setAdjudication(turn === "w" ? "0-1" : "1-0");
    }, 250);
    return () => window.clearInterval(timer);
  }, [started, ending, turn, timeControl.initialMs]);

  const commitUci = useCallback(
    (uci: string) => {
      const next = new Chess(fen);
      try {
        const move = next.move({
          from: uci.slice(0, 2),
          to: uci.slice(2, 4),
          promotion: uci[4] ?? "q",
        });
        if (timeControl.incrementMs) {
          const nextClocks = {
            ...clockRef.current,
            [move.color]: clockRef.current[move.color] + timeControl.incrementMs,
          };
          clockRef.current = nextClocks;
          setClocks(nextClocks);
        }
        setMoves((previous) => [
          ...previous,
          { uci: move.from + move.to + (move.promotion ?? ""), san: move.san, color: move.color },
        ]);
        setFen(next.fen());
        setScore(null);
        return true;
      } catch {
        return false;
      }
    },
    [fen, timeControl.incrementMs],
  );

  useEffect(() => {
    if (!started || ending || turn === playerColor) return;
    const engine = engineRef.current;
    if (!engine || engine.status === "failed") return;
    let active = true;
    setThinking(true);
    const brilliantMode = personality === "brilliant" && difficulty === "ultimate";
    const requestedLines = brilliantMode ? new Chess(fen).moves().length : 5;
    if (brilliantMode) {
      setBrilliantProgress({
        covered: 0,
        total: requestedLines,
        complete: false,
        comparable: false,
        selectedTactical: false,
      });
    }
    void engine
      .analyze(
        fen,
        profile.depth,
        requestedLines,
        brilliantMode
          ? (partial) => {
              const { coveredMoveCount } = countCoveredLegalMoves(fen, partial.lines);
              setBrilliantProgress((previous) =>
                previous?.covered === coveredMoveCount
                  ? previous
                  : {
                      covered: coveredMoveCount,
                      total: requestedLines,
                      complete: false,
                      comparable: false,
                      selectedTactical: false,
                    },
              );
            }
          : undefined,
        brilliantMode ? { ...profile.strength, moveTimeMs: 8_000 } : profile.strength,
      )
      .then((result) => {
        if (!active || !result) return;
        let line;
        if (brilliantMode) {
          const pick = selectBrilliantSearchLine(fen, turn, result.lines);
          setBrilliantProgress({
            covered: pick.coveredMoveCount,
            total: pick.legalMoveCount,
            complete: pick.completeCoverage,
            comparable: pick.scoreComparable,
            selectedTactical: pick.choseTacticalAlternative,
          });
          line = pick.line;
        } else {
          line = selectBotLine(fen, turn, result.lines, personality);
          setBrilliantProgress(null);
        }
        if (!line || !line.pv[0]) {
          setAdjudication(turn === "w" ? "0-1" : "1-0");
          return;
        }
        commitUci(line.pv[0]);
      })
      .finally(() => {
        if (active) setThinking(false);
      });
    return () => {
      active = false;
      engine.cancel();
      setThinking(false);
    };
  }, [started, ending, turn, playerColor, fen, profile, personality, difficulty, commitUci]);

  useEffect(() => {
    if (!started || ending || turn !== playerColor) return;
    const engine = engineRef.current;
    if (!engine || engine.status !== "ready") return;
    let active = true;
    void engine.analyze(fen, 14, 1).then((result) => {
      if (active && result?.lines[0]) setScore(result.lines[0].score);
    });
    return () => {
      active = false;
      engine.cancel();
    };
  }, [started, ending, turn, playerColor, fen, engineStatus]);

  const start = () => {
    const color =
      colorChoice === "random"
        ? Math.random() < 0.5
          ? "w"
          : "b"
        : colorChoice === "white"
          ? "w"
          : "b";
    setPlayerColor(color);
    setOrientation(color);
    setFen(DEFAULT_POSITION);
    setMoves([]);
    const clocksInit = {
      w: timeControl.initialMs || INITIAL_CLOCKS.w,
      b: timeControl.initialMs || INITIAL_CLOCKS.b,
    };
    clockRef.current = clocksInit;
    setClocks(clocksInit);
    setAdjudication(null);
    setScore(null);
    setBrilliantProgress(null);
    setStarted(true);
    gameIdRef.current = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  };

  const humanMove = (from: string, to: string, promotion?: string) => {
    if (!started || ending || thinking || turn !== playerColor) return false;
    const next = new Chess(fen);
    try {
      const move = next.move({ from, to, promotion: promotion ?? "q" });
      if (timeControl.incrementMs) {
        const nextClocks = {
          ...clockRef.current,
          [move.color]: clockRef.current[move.color] + timeControl.incrementMs,
        };
        clockRef.current = nextClocks;
        setClocks(nextClocks);
      }
      setMoves((previous) => [
        ...previous,
        { uci: move.from + move.to + (move.promotion ?? ""), san: move.san, color: move.color },
      ]);
      setFen(next.fen());
      setScore(null);
      return true;
    } catch {
      return false;
    }
  };

  useEffect(() => {
    if (!started || !ending || !moves.length || gameIdRef.current === "") return;
    const id = gameIdRef.current;
    gameIdRef.current = "";
    const pgn = pgnFor(moves, ending, playerColor, botName, new Date());
    const record: BotGameRecord = {
      id,
      createdAt: new Date().toISOString(),
      result: ending,
      white: playerColor === "w" ? "You" : botName,
      black: playerColor === "b" ? "You" : botName,
      pgn,
      difficulty: profile.label,
      personality,
      moveCount: moves.length,
    };
    void saveBotGame(record);
  }, [started, ending, moves, playerColor, botName, profile.label, personality]);

  const undoTraining = () => {
    if (!moves.length) return;
    const count = turn === playerColor ? Math.min(2, moves.length) : 1;
    const remaining = moves.slice(0, Math.max(0, moves.length - count));
    const replay = new Chess();
    for (const item of remaining)
      replay.move({ from: item.uci.slice(0, 2), to: item.uci.slice(2, 4), promotion: item.uci[4] });
    setMoves(remaining);
    setFen(replay.fen());
    setAdjudication(null);
    setScore(null);
  };

  const resign = () => setAdjudication(playerColor === "w" ? "0-1" : "1-0");
  const exportGame = () => {
    if (!ending) return;
    downloadText(
      "chess-insights-bot-game.pgn",
      pgnFor(moves, ending, playerColor, botName, new Date()),
    );
  };
  const currentScore = ending ? terminalScore(fen) : score;
  const displayMoves = moves
    .map(
      (move, i) =>
        `${move.color === "w" ? `${Math.floor(i / 2) + 1}. ` : i % 2 === 1 ? "" : `${Math.floor(i / 2) + 1}… `}${move.san}`,
    )
    .join(" ");

  return (
    <div className="flex flex-col gap-4">
      <div className="panel flex flex-wrap items-center gap-2 p-3">
        <label className="flex items-center gap-2 text-xs text-muted-foreground">
          Bot strength
          <select
            value={difficulty}
            onChange={(e) => {
              const next = e.target.value as BotDifficulty;
              setDifficulty(next);
              if (next !== "ultimate" && personality === "brilliant") setPersonality("balanced");
            }}
            disabled={started && !ending}
            className="rounded border bg-background px-2 py-1 text-foreground"
          >
            {BOT_PROFILES.map((item) => (
              <option key={item.id} value={item.id}>
                {item.label}
              </option>
            ))}
          </select>
        </label>
        <label className="flex items-center gap-2 text-xs text-muted-foreground">
          Style
          <select
            value={personality}
            onChange={(e) => setPersonality(e.target.value as BotPersonality)}
            disabled={started && !ending}
            className="rounded border bg-background px-2 py-1 text-foreground"
          >
            {PERSONALITIES.map((item) => (
              <option
                key={item.id}
                value={item.id}
                disabled={item.id === "brilliant" && difficulty !== "ultimate"}
              >
                {item.label}
                {item.id === "brilliant"
                  ? " · Ultimate only · 8s cap"
                  : item.id !== "balanced"
                    ? " · experimental"
                    : ""}
              </option>
            ))}
          </select>
        </label>
        <label className="flex items-center gap-2 text-xs text-muted-foreground">
          Color
          <select
            value={colorChoice}
            onChange={(e) => setColorChoice(e.target.value as typeof colorChoice)}
            disabled={started && !ending}
            className="rounded border bg-background px-2 py-1 text-foreground"
          >
            <option value="white">Play White</option>
            <option value="black">Play Black</option>
            <option value="random">Random</option>
          </select>
        </label>
        <label className="flex items-center gap-2 text-xs text-muted-foreground">
          Clock
          <select
            value={timeId}
            onChange={(e) => setTimeId(e.target.value)}
            disabled={started && !ending}
            className="rounded border bg-background px-2 py-1 text-foreground"
          >
            {TIME_CONTROLS.map((item) => (
              <option key={item.id} value={item.id}>
                {item.label}
              </option>
            ))}
          </select>
        </label>
        <button
          onClick={start}
          className="ml-auto rounded bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground"
        >
          {started && !ending ? "Restart game" : "Start game"}
        </button>
      </div>

      <p className="text-[11px] leading-relaxed text-muted-foreground">
        Stockfish UCI strength settings are used; the labels are profiles, not calibrated player Elo
        ratings. {PERSONALITIES.find((item) => item.id === personality)?.description}
      </p>
      {personality === "brilliant" && (
        <div className="panel p-3 text-xs text-muted-foreground" role="status" aria-live="polite">
          <span className="font-semibold text-foreground">Experimental search:</span> checks every
          legal first move with MultiPV in one search capped at 8 seconds per bot turn. A tactical
          candidate is preferred only within 2.5 win-percentage points of the best searched line.
          This is not a full game-tree search or a Hunter-verified Brilliant classification.
          {brilliantProgress && started && (
            <div className="mt-1 text-foreground">
              {thinking
                ? `Legal moves searched: ${brilliantProgress.covered}/${brilliantProgress.total}`
                : brilliantProgress.complete && brilliantProgress.comparable
                  ? `All ${brilliantProgress.total} legal moves returned comparable lines. ${brilliantProgress.selectedTactical ? "Selected a near-best tactical candidate." : "No tactical alternative passed the score guardrail; selected the best engine line."}`
                  : brilliantProgress.complete
                    ? `All legal moves returned a line, but search depths differed; selected the best returned engine line without tactical bias.`
                    : `Search coverage ${brilliantProgress.covered}/${brilliantProgress.total}; incomplete coverage falls back to the best move among returned lines.`}
            </div>
          )}
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_340px]">
        <section className="flex flex-col gap-2">
          <div className="flex items-center justify-between px-1 text-sm">
            <span>{orientation === "w" ? botName : "You"}</span>
            <span className="rounded bg-panel px-2 py-1 font-mono">
              {clockText(clocks[orientation === "w" ? "b" : "w"], !timeControl.initialMs)}
            </span>
          </div>
          <div className="flex gap-2">
            <EvalBar score={currentScore} orientation={orientation} />
            <div className="w-full max-w-[min(78vh,620px)]">
              <Board
                fen={fen}
                orientation={orientation}
                lastMove={
                  moves.length
                    ? {
                        from: moves[moves.length - 1].uci.slice(0, 2),
                        to: moves[moves.length - 1].uci.slice(2, 4),
                      }
                    : null
                }
                onMove={humanMove}
              />
            </div>
          </div>
          <div className="flex items-center justify-between px-1 text-sm">
            <span>
              {orientation === "w" ? "You" : botName}
              {turn === playerColor && started && !ending ? " · your turn" : ""}
            </span>
            <span className="rounded bg-panel px-2 py-1 font-mono">
              {clockText(clocks[orientation], !timeControl.initialMs)}
            </span>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setOrientation((o) => (o === "w" ? "b" : "w"))}
              className="rounded border px-3 py-1.5 text-xs hover:bg-accent"
            >
              Flip board
            </button>
            <button
              onClick={undoTraining}
              disabled={!moves.length || !started}
              className="rounded border px-3 py-1.5 text-xs hover:bg-accent disabled:opacity-40"
            >
              Undo · training
            </button>
            <button
              onClick={resign}
              disabled={!started || !!ending}
              className="rounded border px-3 py-1.5 text-xs hover:bg-accent disabled:opacity-40"
            >
              Resign
            </button>
            {ending && (
              <button
                onClick={exportGame}
                className="ml-auto rounded bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground"
              >
                Export PGN
              </button>
            )}
          </div>
        </section>

        <aside className="flex flex-col gap-3">
          <div className="panel p-3">
            <div className="text-[11px] uppercase tracking-wider text-muted-foreground">
              Engine status
            </div>
            <div className="mt-1 text-sm">
              {engineStatus === "ready"
                ? "Stockfish ready"
                : engineStatus === "failed"
                  ? "Engine unavailable"
                  : "Stockfish starting…"}
              {thinking ? " · thinking" : ""}
            </div>
            <div className="mt-1 text-xs text-muted-foreground">
              {profile.note} · depth {profile.depth}
            </div>
            {currentScore && (
              <div className="mt-2 font-mono text-lg">Evaluation {formatScore(currentScore)}</div>
            )}
          </div>
          <div className="panel min-h-36 p-3">
            <div className="mb-2 flex items-center justify-between text-sm font-semibold">
              <span>Move history</span>
              <span className="font-mono text-xs text-muted-foreground">{moves.length} ply</span>
            </div>
            {moves.length ? (
              <p className="max-h-40 overflow-auto font-mono text-xs leading-6">{displayMoves}</p>
            ) : (
              <p className="text-xs text-muted-foreground">
                Start a game to begin. Moves are validated by chess.js.
              </p>
            )}
            {ending && (
              <div className="mt-3 rounded border border-primary/30 bg-primary/10 p-2 text-sm font-semibold">
                Game over · {ending}
                {chess.isCheckmate()
                  ? " · checkmate"
                  : chess.isDraw()
                    ? " · draw"
                    : adjudication
                      ? " · resigned or time expired"
                      : ""}
              </div>
            )}
            {started && !ending && (
              <p className="mt-3 text-xs text-muted-foreground">
                {thinking
                  ? `${botName} is thinking…`
                  : turn === playerColor
                    ? "Your move"
                    : `${botName} to move`}
              </p>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}
