# Upgrade Outcomes

Each item remains open until its complete behavior has been implemented and supported by evidence. This tracker keeps the user's complete requested outcomes visible; a working interface alone does not complete an item.

## A. Preserve and integrate the existing Analyzer

- [x] Preserve the existing Analyzer, PGN import, legal chess move handling, move navigation, evaluation bar and current classifications; preserve current visual styling wherever possible; do not unnecessarily duplicate Stockfish implementations; do not remove functionality, hardcode chess results, generate fake engine evaluations, or claim features/tests complete without implementation and test evidence.
- [x] Inspect and document current board, Stockfish, PGN parser, analysis pipeline, classification, routing/navigation, reusable components, worker/WASM assets and performance constraints. Establish existing Analyzer regression coverage before changing behavior.
- [x] Existing Analyzer remains accessible, imports/replays/analyzes PGNs, shows classifications/accuracy, navigates the game and variations, and retains its existing Stockfish worker; baseline and post-change Analyzer classification/routing tests pass.

## B. Bot Arena navigation and home

- [x] Add a primary **BOT ARENA** section while retaining an accessible Analyzer section. The Bot Arena screen includes **Play Against Bots**, **Brilliant Hunter**, **Discovery Lab**, **Recent Bot Games**, **Brilliant Discoveries History**, and **Engine Status**. It uses a professional dark chess interface, clear typography, high-quality board, smooth transitions, evaluation indicators, classification colors and responsive desktop/mobile layout without overcrowding or redesigning unrelated sections.
- [x] Bot Arena home includes a premium header, bot cards, difficulty selection, recent games, Hunter status and discovery statistics. Main layout exposes Play Against Bots, Brilliant Hunter, Discovery Lab, Game History and Discovery History.

## C. Bot Playing Arena

- [x] Provide Beginner, Casual, Intermediate, Advanced, Expert, Master, Grandmaster and Ultimate Engine profiles. Difficulty changes genuine supported Stockfish settings (`UCI_LimitStrength`, `UCI_Elo`, Skill Level, search depth and/or time management). Never advertise an exact Elo unless calibrated and verified. Ultimate Engine uses the strongest practical device/engine configuration. **Note:** UCI Elo is presented as an engine control target, not a calibrated player rating; Ultimate is unrestricted single-thread Stockfish with depth cap 22.
- [x] Provide Aggressive Attacker, Defensive Player, Tactical Specialist, Positional Strategist, Endgame Specialist and Balanced Player. Personality affects actual move selection/configuration; label unreliable/heuristic modes experimental.
- [x] Implement play as White, play as Black, random color, bot and time-control selection, standard legal chess rules, castling, en passant, promotion, check/checkmate/draw detection, resign, restart, training-mode undo, board flip, move history, live evaluation bar and engine-thinking indicator.
- [x] Bot makes legal moves only. Engine work is single-search-at-a-time and stale searches are cancelled/settled to prevent overlapping moves.
- [ ] After each completed game offer Analyze Game, move classifications, accuracy estimates, best missed moves, blunders, tactical opportunities, game summary, opening identification and key turning points by reusing the existing analysis engine.
- [ ] Persist bot-game history, restore saved games, export PGN, delete individual games and clear history.

## D. Brilliant Hunter scan and report

- [ ] User can import a random PGN, upload a PGN file, paste PGN notation, select a previously played game or analyze one board position. Hunter investigates extraordinary opportunities: brilliant sacrifices, hidden tactics, unexpected resources, quiet brilliant moves, deep positional ideas, strong defenses, forced mates and counterattacks; do not mark every sacrifice Brilliant.
- [ ] For every scanned move reconstruct the exact pre-move position, side to move, actual move, material balance, king-safety signal, legal candidates, relevant FEN and PGN reference.
- [ ] Generate multiple candidates using Stockfish MultiPV and practical legal-move enumeration. Consider sacrifices, non-obvious captures, quiet moves, checks, intermediate moves, defensive resources and tactical-geometry changes.
- [ ] Evaluate actual material consequences and distinguish sound, speculative, forced, temporary and unsound sacrifices involving queen, rook, bishop, knight, exchange or pawn.
- [ ] Investigate forcing variations, checks, captures, threats, zwischenzug, deflection, decoy, clearance, attraction, interference, discovered attacks, mating nets, defensive resources and counterattacks using engine-verified resulting positions.
- [ ] For each candidate calculate strongest opponent response and alternative defenses; search the resulting continuation; establish whether advantage survives; distinguish forced ideas from opponent-mistake-dependent ideas; reject candidates that fail objective verification. Never call a move Brilliant merely because the opponent later blundered.
- [ ] Also investigate quiet positional/defensive moves for piece coordination, king safety, activity, restriction and long-term threats. Explain the engine-backed reason or say inconclusive.
- [x] Classifications are Confirmed Brilliant, Strong Candidate, Interesting, Speculative, Refuted or Needs Deeper Analysis. Only call a move Confirmed Brilliant after the current depth-20/multi-line gate; insufficient depth/time is provisional.
- [ ] Keep objective strength, tactical complexity, human discovery difficulty and classification confidence as separate measurements. Scoring is transparent and is not mislabeled as probability. Include tactical soundness, sacrifice quality, evaluation stability, best-response verification, forcing continuation, unexpectedness, discovery difficulty, strategic impact and alternatives.
- [ ] Report total moves scanned, positions investigated, candidate moves examined, confirmed discoveries, strong candidates, refuted sacrifices, interesting opportunities, analysis depth/time and unverified positions. Each discovery contains move number, actual move, classification, before/after boards, main variation, best opponent response, material consequences, evaluations, explanation and confidence. Clicking navigates to the actual move and permits continuation exploration.
- [x] Hunter screen provides PGN upload/paste, game information, bounded scan configuration, progress, results, before/after boards, variation panel and explanations. The separate game-to-Analyzer navigation and broader variation exploration remain open.
- [ ] Explanations answer why unusual, what is sacrificed/threatened, what happens if accepted, best defense, why ordinary moves are worse, objective soundness and discovery difficulty; use engine variations as factual foundation and mark inconclusive explanations.

## E. Discovery Lab and safe engine infrastructure

- [ ] Discovery Lab provides an interactive board, FEN input, PGN input, position setup, side-to-move selection, Scan Position, candidate list, Hunter results, variation exploration, evaluation, best defense and refutation analysis. Users can play a move, scan the resulting position and compare it with alternatives.
- [x] Reuse the existing Stockfish integration and preserve worker/WASM paths. Extend its UCI options for strength and timed search; settle cancellation/destruction promises, preserve single-search sequencing, use MultiPV/depth/cache/readiness/status/error handling, and keep work in Web Workers. More extensive queueing/timeouts/resource tuning remain open.
- [ ] Work in Web Workers and check desktop-browser plus Android WebView/Capacitor behavior; provide graceful fallback if unsupported. Keep the application responsive with background calculations, queued/cached analysis, PGN result caching, cancellation, progress, memory management, cleanup, duplicate-request prevention and mobile CPU-aware limits. Do not run full-game deep analysis concurrently with live bot search on low-resource devices. Provide engine status.
- [ ] Advanced controls include search depth, candidate count, time per position, total game-analysis time, sacrifice sensitivity, tactical sensitivity, Fast/Balanced/Deep scan, safe device-aware defaults, workload estimates, pause/resume/cancel and protection against unlimited loops.
- [ ] Store bot games, PGN games, discoveries, settings, prior scans and engine preferences using the existing persistence architecture or IndexedDB for larger records. Avoid duplicate engine data. Provide PGN/report exports, individual game deletion, history clearing and restore.

## F. Brilliant Move DNA

- [ ] Convert only verified discoveries into structured DNA records with unique ID, original game reference, FEN, PGN variation, motif, sacrifice information, engine evaluation, best defense, verification state, confidence and discovery date.
- [ ] Extract tactical motifs and piece relationships; store sequences/verified variations; identify recurring structures; compare future positions using normalization, piece relationships, legal-move structure and motifs—not exact FEN alone. Do not claim identical combinations based only on similar-looking boards.
- [x] DNA Explorer browses verified-only records, searches and filters derived tags/sacrifice features, compares normalized position structures, exports original PGN/source records, explores saved variations, deletes individual patterns and exports records. Similarity is explicitly structural—not proof of the same combination—and unverified candidates remain excluded.

## G. HUMAN VS HUNTER

- [ ] Load a position from a game; hide engine best move/classification; let user investigate; accept a legal move; evaluate and compare it with verified Hunter findings; then reveal candidate/continuation. Support unlimited thinking, optional timer, hints, reveal, multiple attempts, move comparison, post-submission engine explanation and training history.
- [ ] Track correct brilliant findings, tactical candidates, missed discoveries, elapsed time, hint use and motif recognition. Do not reward random guesses; only objectively verified solutions receive credit; accept multiple solutions only where engine analysis establishes equivalence/sufficient strength.

## H. Verified Brilliant Training

- [ ] Generate puzzles only from verified combinations. Each puzzle has starting FEN, side to move, source PGN reference, solution, best response, main continuation, motif, complexity-derived difficulty and engine verification state.
- [ ] Difficulty levels: Beginner Tactics, Intermediate Combinations, Advanced Sacrifices, Expert Brilliant Moves and Grandmaster Challenges, based on tactical complexity/search difficulty/candidate ambiguity rather than arbitrary labels.
- [ ] Support Daily Brilliant Challenge, random puzzle, motif/sacrifice filters, unlimited practice, timed challenge, incorrect-answer review, full-combination replay and personal performance history. Never use an unverified move or a forced loss as a puzzle solution; verify against best defense and allow objectively equivalent multiple solutions.

## I. Discovery Benchmark

- [ ] Maintain an attributed, verification-status-aware dataset of documented games/positions containing famous sacrifices, quiet tactics, defensive resources, strong non-sacrifices, unsound sacrifices, ordinary moves and no-discovery positions. Include Kasparov–Topalov 1999; investigate 24.Rxd4, 25.Re7+ and 36.Bf1 as candidates, not hardcoded answers.
- [ ] Run Hunter per position and record candidates, classifications and engine evaluations; compare with curated references while distinguishing expert annotation from objective engine verification. Generate reports; reruns retain historical results and track engine/search/classifier versions. Algorithm changes trigger regression tests.
- [x] On each completed user-supplied benchmark run, calculate precision, recall, false-positive rate, false-negative rate, candidate coverage and verification completion rate from actual engine results. No benchmark metrics are seeded or shown before a run; incomplete runs are not reported.
- [ ] Dashboard shows benchmark positions, confirmed discoveries, correct labels, false positives, missed discoveries, precision, recall, engine coverage and performance by motif. Users can rerun after classifier changes.

## J. Integration and release evidence

- [ ] Verified discovery becomes eligible for DNA storage; DNA similarity assists future scans without claiming identity; Human vs Hunter and training use verified-only records; benchmark evaluates classifier changes; regression tests run after classifier changes.
- [ ] Never train on unverified discoveries, promote an unverified pattern to confirmed, use benchmark labels as hardcoded runtime answers, inflate precision by omitting difficult cases, or lose historical benchmarks. Track engine version, search configuration and classifier version for every result.
- [ ] Test bot legality, turn order, mate/draw/promotion, no duplicate moves, difficulty settings, strongest practical profile and cancellation; test Hunter on Kasparov–Topalov, Morphy's Opera Game, known and unsound sacrifices, quiet tactical game and a game without obvious brilliancies; test false-positive resistance; test large PGNs, pause/resume/cancel, cleanup, mobile responsiveness, UI responsiveness and memory; fully retest original Analyzer.
- [ ] Final report states implementation and tests separately for Bot Arena, Hunter, DNA, Human-vs-Hunter, training and benchmark; lists changed files, engine design, bot strength, Hunter methodology, tests, limits, build and Android compatibility. Deliver updated project ZIP. Never claim an APK unless a real APK exists and has been verified.

## Delivered checkpoint — 2026-11-08; later status updated 2026-11-10

- Source upgrade archive prepared; see `UPGRADE-REPORT.md` for delivered scope, per-feature test evidence and remaining work.
- Verification: 12 tests passed; TypeScript check and production web build passed; lint completed with 0 errors and 6 pre-existing shared-UI warnings.
- Bot Arena's oversized landing header was tightened to the existing Analyzer workspace style and visually compared in the desktop preview; mobile screenshot QA remains open.
- At the original 2026-11-08 checkpoint the supplied source contained no Android/Gradle/Capacitor project. Superseded by the Android packaging work recorded below; the unrelated unchecked requirements above remain open.


## Brilliant Search follow-up — 2026-11-10

- [x] Ultimate Engine includes an optional Brilliant Search style. Per bot turn it requests MultiPV for every legal root move, up to an 8-second search cap, shows returned legal-move coverage, considers material/tactical candidates only within a 2.5 win-percentage-point tolerance of the strongest returned line, and applies that preference only when every legal move has a returned line at the same search depth. Otherwise it falls back to the strongest returned engine line. UI explicitly says this is experimental, not a complete game-tree search, and not a Hunter-verified Brilliant label.
- [x] Automated regression coverage for full move coverage, tactical near-best selection, objective-score guardrail, mismatched depths and incomplete-coverage fallback. Latest suite: 16 tests passed; TypeScript check passed; lint has 0 errors and 6 existing shared-UI warnings.
- [ ] Run on real Stockfish WASM in Android/WebView and representative high-branching positions to measure the 8-second cap, MultiPV coverage and device load. If full coverage is not returned, the implemented fallback stays active and the UI reports that limitation.
- [ ] A future independently verified Brilliant-classification chooser would need after-move best-defense re-search and sufficient confirmation depth. Current Brilliant Search does not claim this.

## Android build follow-up — 2026-11-10

- [x] Added Capacitor Android 8, a local `.output/public/index.html` SPA shell, `capacitor.config.ts`, generated Android Gradle project, and local Stockfish JS/WASM assets. No hosted URL is required.
- [x] `pnpm build:android` is the web-build-and-sync command. Android debug build succeeds with the Gradle wrapper using JDK 21 and Android SDK Platform 36. APK signature verification passed and package ID is `com.chessinsights.engine`.
- [x] Added `README-ANDROID.md` with Windows, macOS and Linux build steps. Debug APK is available at `android/app/build/outputs/apk/debug/app-debug.apk`.
- [ ] Install and test on an actual Android phone or emulator, including Stockfish WebWorker/WASM, IndexedDB/storage, board input and long-thinking/resource behavior. Debug APK is for testing; production signing/Play Store release remains separate.
